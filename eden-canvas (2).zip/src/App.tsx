import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { StudioWorkspace } from './components/StudioWorkspace';
import { DeferredGateModal } from './components/DeferredGateModal';
import { MonetizationModal } from './components/MonetizationModal';
import { ServerlessEngineViewer } from './components/ServerlessEngineViewer';
import { Footer } from './components/Footer';
import { ShieldCheck, Sparkles, AlertTriangle } from 'lucide-react';

export default function App() {
  // Application State
  const [credits, setCredits] = useState<number>(1); // 1 free credit initially
  const [maxCredits, setMaxCredits] = useState<number>(5);
  const [isEmailVerified, setIsEmailVerified] = useState<boolean>(false);
  const [isPro, setIsPro] = useState<boolean>(false);

  // Modal and Flow States
  const [isDeferredModalOpen, setIsDeferredModalOpen] = useState<boolean>(false);
  const [progressStep, setProgressStep] = useState<number>(0);
  const [progressPercent, setProgressPercent] = useState<number>(0);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [isBlurred, setIsBlurred] = useState<boolean>(false);
  const [isPricingModalOpen, setIsPricingModalOpen] = useState<boolean>(false);
  const [isEngineModalOpen, setIsEngineModalOpen] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'info' | 'refund' } | null>(null);

  // Check URL parameters for ?pro=unlocked or autostart
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('pro') === 'unlocked') {
      setIsPro(true);
      setCredits(150);
      setMaxCredits(150);
      setIsEmailVerified(true);
      showToast('VIP Studio Pass Unlocked! 150 Credits & Digital Vault Active.', 'success');
    }
  }, []);

  const showToast = (text: string, type: 'success' | 'info' | 'refund' = 'info') => {
    setToastMessage({ text, type });
    setTimeout(() => {
      setToastMessage(null);
    }, 4500);
  };

  // Trigger Makeover Generation Flow (Deferred Gratification Machine)
  const handleTriggerGenerate = (config: {
    roomType: string;
    styleId: string;
    activePresets: string[];
    userPrompt: string;
  }) => {
    if (credits <= 0) {
      setIsPricingModalOpen(true);
      return;
    }

    // Deduct 1 credit
    setCredits(prev => Math.max(0, prev - 1));
    setIsGenerating(true);
    setProgressPercent(10);
    setProgressStep(0);

    // If user has NOT verified email, run the multi-step animation and pause at 99%
    if (!isEmailVerified) {
      setIsDeferredModalOpen(true);

      const step1Timer = setTimeout(() => {
        setProgressStep(1);
        setProgressPercent(35);
      }, 700);

      const step2Timer = setTimeout(() => {
        setProgressStep(2);
        setProgressPercent(65);
      }, 1500);

      const step3Timer = setTimeout(() => {
        setProgressStep(3);
        setProgressPercent(88);
      }, 2300);

      const step4Timer = setTimeout(() => {
        setProgressPercent(99);
        setIsBlurred(true);
        setIsGenerating(false);
      }, 3100);

      return () => {
        clearTimeout(step1Timer);
        clearTimeout(step2Timer);
        clearTimeout(step3Timer);
        clearTimeout(step4Timer);
      };
    } else {
      // User is already verified: complete generation cleanly
      setTimeout(() => {
        setIsGenerating(false);
        showToast('Makeover synthesized! ControlNet Geometry Lock active.', 'success');
      }, 1400);
    }
  };

  // Called when user submits a valid email through ZeroBounce check
  const handleEmailVerified = (email: string) => {
    setIsEmailVerified(true);
    setIsBlurred(false);
    setIsDeferredModalOpen(false);
    // Add 4 bonus credits (1 spent + 4 bonus = 4 remaining of 5 max)
    setCredits(prev => prev + 4);
    setMaxCredits(5);
    showToast(
      `Welcome, ${email}! Your makeover is unblurred & 4 bonus credits have been credited to your account.`,
      'success'
    );
  };

  // Simulate an HTTP 500 error to prove the Zero-Risk Credit Guarantee
  const handleSimulateRefund = () => {
    showToast('Simulating API error: HTTP 500 (GPU worker timeout)...', 'info');

    setTimeout(() => {
      // Automatic credit refund triggered
      setCredits(prev => prev + 1);
      showToast(
        'Zero-Risk Credit Guarantee: HTTP 500 caught. 1 credit has been automatically restored to your account!',
        'refund'
      );
    }, 1200);
  };

  // Add credits from monetization modal
  const handleAddCredits = (amount: number, proActivated: boolean = false) => {
    setCredits(prev => prev + amount);
    setMaxCredits(prev => Math.max(prev, prev + amount));
    if (proActivated) {
      setIsPro(true);
      setIsEmailVerified(true);
    }
    showToast(`Added ${amount} credits to your account!`, 'success');
  };


  const scrollToStudio = () => {
    const studioEl = document.getElementById('studio');
    if (studioEl) {
      studioEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF8F5] text-[#2C2724] relative selection:bg-[#C69C6D]/30 selection:text-[#4A3B32]">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 max-w-md p-4 rounded-2xl glass-luxury-dark text-[#FAF8F5] shadow-2xl border border-[#C69C6D]/40 flex items-start gap-3 animate-slide-up">
          {toastMessage.type === 'refund' ? (
            <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
          ) : toastMessage.type === 'success' ? (
            <Sparkles className="w-5 h-5 text-[#C69C6D] shrink-0 mt-0.5" />
          ) : (
            <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          )}
          <div className="text-xs leading-relaxed">
            <p className="font-semibold text-[11px] uppercase tracking-wider text-[#C69C6D] mb-0.5">
              {toastMessage.type === 'refund' ? 'Guarantee Triggered' : 'Notification'}
            </p>
            <p>{toastMessage.text}</p>
          </div>
        </div>
      )}

      {/* Top Bar Contract Navigation */}
      <Header
        credits={credits}
        maxCredits={maxCredits}
        isPro={isPro}
        onOpenPricing={() => setIsPricingModalOpen(true)}
        onOpenEngine={() => setIsEngineModalOpen(true)}
        onScrollToStudio={scrollToStudio}
      />

      {/* Main Page Layout */}
      <main className="flex-1">
        {/* 1. 3D Modern Hero & Auto-Gliding Before/After Visualizer */}
        <HeroSection
          onStartMakeover={scrollToStudio}
          onExplorePresets={() => {
            const presetsEl = document.getElementById('presets');
            if (presetsEl) presetsEl.scrollIntoView({ behavior: 'smooth' });
          }}
        />

        {/* 2. Split-Screen Studio Workspace */}
        <StudioWorkspace
          credits={credits}
          isEmailVerified={isEmailVerified}
          onTriggerGenerate={handleTriggerGenerate}
          onOpenPricing={() => setIsPricingModalOpen(true)}
          onSimulateRefund={handleSimulateRefund}
          isGenerating={isGenerating}
          isBlurred={isBlurred}
          lastGeneratedTime={null}
        />
      </main>

      {/* Quiet Luxury Footer */}
      <Footer
        onOpenPricing={() => setIsPricingModalOpen(true)}
        onOpenEngine={() => setIsEngineModalOpen(true)}
        onScrollToStudio={scrollToStudio}
      />

      {/* Deferred Gratification Gate Modal */}
      <DeferredGateModal
        isOpen={isDeferredModalOpen}
        progressStep={progressStep}
        progressPercent={progressPercent}
        onEmailVerified={handleEmailVerified}
        onClose={() => setIsDeferredModalOpen(false)}
      />

      {/* Hybrid Monetization & Pro Vault Modal */}
      <MonetizationModal
        isOpen={isPricingModalOpen}
        onClose={() => setIsPricingModalOpen(false)}
        onAddCredits={handleAddCredits}
        isPro={isPro}
      />

      {/* Netlify Serverless Engine Code Viewer */}
      <ServerlessEngineViewer
        isOpen={isEngineModalOpen}
        onClose={() => setIsEngineModalOpen(false)}
      />
    </div>
  );
}
