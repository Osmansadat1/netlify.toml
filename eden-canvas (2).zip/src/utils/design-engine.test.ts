import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildAmazonAffiliateUrl,
  validateEmailWithZeroBounce,
  compileDesignPrompt,
  resolvePseoRoute,
  AFFILIATE_TAG,
  POSITIVE_RENTER_PROMPT,
  NEGATIVE_RENTER_PROMPT
} from './design-engine.ts';

test('buildAmazonAffiliateUrl always appends or updates affiliate tag', () => {
  const url1 = buildAmazonAffiliateUrl('B087T1L9K8');
  assert.match(url1, new RegExp(`tag=${AFFILIATE_TAG}`));
  assert.ok(url1.startsWith('https://www.amazon.com/dp/B087T1L9K8'));

  const url2 = buildAmazonAffiliateUrl('https://www.amazon.com/dp/B0BG8R34T2?ref=my_ref');
  assert.match(url2, new RegExp(`tag=${AFFILIATE_TAG}`));
  assert.match(url2, /ref=my_ref/);
});

test('validateEmailWithZeroBounce validates valid emails and blocks disposable domains', () => {
  // Valid email
  const validResult = validateEmailWithZeroBounce('sarah.renter@gmail.com');
  assert.equal(validResult.valid, true);
  assert.equal(validResult.isDisposable, false);

  // Invalid email format
  const invalidResult = validateEmailWithZeroBounce('not-an-email');
  assert.equal(invalidResult.valid, false);
  assert.equal(invalidResult.isDisposable, false);

  // Disposable email domains (ZeroBounce filter)
  const disposable1 = validateEmailWithZeroBounce('test@mailinator.com');
  assert.equal(disposable1.valid, false);
  assert.equal(disposable1.isDisposable, true);

  const disposable2 = validateEmailWithZeroBounce('tempuser@tempmail.com');
  assert.equal(disposable2.valid, false);
  assert.equal(disposable2.isDisposable, true);
});

test('compileDesignPrompt injects positive and negative renter constraints', () => {
  const compiled = compileDesignPrompt({
    roomType: 'kitchen',
    styleId: 'japandi',
    activePresetIds: ['honey-oak-kitchen'],
    userPrompt: 'Add warm lighting'
  });

  // Verify positive prompt includes renter baseline constraints
  assert.match(compiled.positivePrompt, /peel-and-stick vinyl wrap/);
  assert.match(compiled.positivePrompt, /Japandi aesthetic/);
  assert.match(compiled.positivePrompt, /calacatta marble backsplash/i);
  assert.match(compiled.positivePrompt, /Add warm lighting/);
  assert.match(compiled.positivePrompt, new RegExp(POSITIVE_RENTER_PROMPT.slice(0, 30)));

  // Verify negative prompt prohibits structural demolition
  assert.equal(compiled.negativePrompt, NEGATIVE_RENTER_PROMPT);
  assert.match(compiled.negativePrompt, /demolition/);
  assert.match(compiled.negativePrompt, /drilled fixtures/);

  // Verify ControlNet depth configuration
  assert.equal(compiled.controlNetConfig.preprocessor, 'depth_midas');
  assert.equal(compiled.controlNetConfig.conditioningScale, 0.88);
});

test('resolvePseoRoute returns matching route or default fallback', () => {
  const route = resolvePseoRoute('/makeover/kitchen/japandi/peel-and-stick');
  assert.equal(route.room, 'kitchen');
  assert.equal(route.style, 'japandi');
  assert.equal(route.depositSafetyScore, 100);
  assert.ok(route.faqs.length >= 2);

  const fallback = resolvePseoRoute('/unknown/route');
  assert.ok(fallback.h1Title);
  assert.equal(fallback.depositSafetyScore, 100);
});
