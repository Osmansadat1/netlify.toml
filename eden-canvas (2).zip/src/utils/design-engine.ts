/**
 * Eden Canvas Design & Renter Constraint Engine
 * Pure business logic for prompt compilation, zero-damage validation, 
 * affiliate tracking, disposable email verification, and pSEO route resolution.
 */

export const AFFILIATE_TAG = 'Sayedosmanema-20';

export const POSITIVE_RENTER_PROMPT = 
  'Command-strip wall art, tension-rod curtains, oversized washable area rug, plug-in 2700K floor lamps, freestanding shelving, removable peel-and-stick vinyl wrap, photorealistic editorial interior photography, soft golden hour light.';

export const NEGATIVE_RENTER_PROMPT = 
  'structural changes, removed walls, changed window frames, hardwired pendant lights, recessed lighting, drilled fixtures, demolition, construction.';

export interface StyleDefinition {
  id: string;
  name: string;
  tagline: string;
  materials: string[];
  palette: string[];
  promptKeywords: string;
}

export const STYLES: Record<string, StyleDefinition> = {
  japandi: {
    id: 'japandi',
    name: 'Japandi',
    tagline: 'Japanese minimalism meets Scandinavian functional warmth',
    materials: ['Pale Ash Wood', 'Wabi-Sabi Ceramics', 'Unbleached Linen', 'Matte Black Slender Accents'],
    palette: ['#FAF8F5', '#F0ECE1', '#6E7864', '#4A3B32'],
    promptKeywords: 'Japandi aesthetic, warm minimalist serenity, pale ash woodwork, textured linen, handmade wabi-sabi pottery, low-profile oak furniture, warm ambient lighting'
  },
  'organic-modern': {
    id: 'organic-modern',
    name: 'Organic Modern',
    tagline: 'Curved silhouettes, textured travertine, and botanical serenity',
    materials: ['Travertine & Limewash', 'Cream Bouclé', 'Warm Oak', 'Olive Foliage'],
    palette: ['#FAF8F5', '#EFECE6', '#C69C6D', '#4A3B32'],
    promptKeywords: 'Organic modern luxury, cream bouclé sofa, fluted wood accents, travertine surfaces, large potted olive tree, warm sculptural silhouettes, soft drapery'
  },
  'cozy-modern': {
    id: 'cozy-modern',
    name: 'Cozy Modern',
    tagline: 'Deep walnut tones, tactile wool layers, and amber 2700K warmth',
    materials: ['Walnut Finish', 'Heavy Wool Throws', 'Smoked Glass', 'Brass Accents'],
    palette: ['#F5F2EB', '#C69C6D', '#4A3B32', '#2C2724'],
    promptKeywords: 'Cozy modern interior, rich walnut wood, layered wool rugs, ambient warm amber glow, tailored comfortable seating, curated bookshelf styling'
  },
  'quiet-luxury': {
    id: 'quiet-luxury',
    name: 'Quiet Luxury',
    tagline: 'Understated elegance, museum-grade framing, and bespoke greige',
    materials: ['Matte Greige', 'Calacatta Veining', 'Brushed Brass', 'Belgian Linen'],
    palette: ['#FAF8F5', '#B8B2A6', '#C69C6D', '#2C2724'],
    promptKeywords: 'Quiet luxury interior, high-end understated finishes, museum-quality framed prints with command mounts, brushed brass plug-in sconces, refined greige textiles'
  },
  'refined-farmhouse': {
    id: 'refined-farmhouse',
    name: 'Refined Farmhouse',
    tagline: 'Rustic warmth updated with clean lines and zero-drill shiplap',
    materials: ['Peel-and-Stick Shiplap', 'Woven Rattan', 'Weathered Oak', 'Matte Black Iron'],
    palette: ['#FAF8F5', '#F0ECE1', '#8C8275', '#3A3530'],
    promptKeywords: 'Refined modern farmhouse, peel-and-stick vertical shiplap accent, woven seagrass baskets, freestanding rustic oak console, crisp off-white slipcovers'
  }
};

export interface RenterFixPreset {
  id: string;
  title: string;
  shortDesc: string;
  depositSafetyScore: number;
  promptEnhancement: string;
  typicalSavings: string;
}

export const RENTER_PRESETS: Record<string, RenterFixPreset> = {
  'honey-oak-kitchen': {
    id: 'honey-oak-kitchen',
    title: '90s Honey-Oak Kitchen Fix',
    shortDesc: 'Matte vinyl cabinet wraps & peel-and-stick marble backsplash',
    depositSafetyScore: 100,
    promptEnhancement: 'matte greige and sage peel-and-stick vinyl cabinet wrap, removable calacatta marble backsplash tile stickers, brushed brass peel-and-stick handle covers',
    typicalSavings: '$4,200 vs cabinet refacing'
  },
  'hide-carpet': {
    id: 'hide-carpet',
    title: 'Hide Ugly Rental Carpet',
    shortDesc: 'Oversized washable area rugs layered over existing flooring',
    depositSafetyScore: 100,
    promptEnhancement: 'oversized 9x12 neutral washable textured area rug completely covering apartment carpet, low-profile rug pad, seamless border alignment',
    typicalSavings: '$2,800 vs carpet replacement'
  },
  'zero-drill-lighting': {
    id: 'zero-drill-lighting',
    title: 'Zero-Drill Wall & Lighting',
    shortDesc: 'Command-strip gallery walls, tension-rod drapes & 2700K floor lamps',
    depositSafetyScore: 100,
    promptEnhancement: 'heavyweight command-strip hung museum gallery frames, spring-tension rod Belgian linen curtains without drilling, warm 2700K plug-in arched floor lamp',
    typicalSavings: '$1,500 security deposit saved'
  },
  'rental-bathroom': {
    id: 'rental-bathroom',
    title: 'Rental Bathroom Refresh',
    shortDesc: 'Removable moisture-resistant wallpaper & tension storage',
    depositSafetyScore: 100,
    promptEnhancement: 'moisture-resistant removable peel-and-stick textured wallpaper, freestanding matte black tension shower caddy, magnetic frameless mirror overlay',
    typicalSavings: '$3,100 vs bathroom tile remodeling'
  }
};

export interface ShoppableProduct {
  id: string;
  title: string;
  category: 'kitchen' | 'living' | 'bedroom' | 'bathroom' | 'lighting' | 'decor';
  price: number;
  priceFormatted: string;
  leaseSafeBadge: string;
  amazonAsin: string;
  rating: number;
  reviewCount: number;
  rentalFeature: string;
  thumbnail: string;
}

export const RENTER_SHOPPABLE_CATALOG: ShoppableProduct[] = [
  {
    id: 'vinyl-wrap-sage',
    title: 'Matte Greige & Sage Removable Architectural Vinyl Cabinet Film (17.7" x 393")',
    category: 'kitchen',
    price: 28.99,
    priceFormatted: '$28.99',
    leaseSafeBadge: '100% Residue-Free Removal',
    amazonAsin: 'B087T1L9K8',
    rating: 4.8,
    reviewCount: 3410,
    rentalFeature: 'Instantly covers 90s honey oak; peels off cleanly with hair dryer at move-out.',
    thumbnail: 'cabinet-wrap'
  },
  {
    id: 'peel-stick-marble',
    title: 'Thickened Calacatta Marble Peel-and-Stick Backsplash Tiles (10 Sheets)',
    category: 'kitchen',
    price: 36.50,
    priceFormatted: '$36.50',
    leaseSafeBadge: 'Zero Wall Tear Tested',
    amazonAsin: 'B091J3M81Q',
    rating: 4.7,
    reviewCount: 1980,
    rentalFeature: 'Heat & humidity resistant behind stove, leaves zero residue on rental drywall.',
    thumbnail: 'marble-tiles'
  },
  {
    id: 'washable-rug-9x12',
    title: 'Japandi Textured Oversized Washable Area Rug 9x12 ft (Cream/Oatmeal)',
    category: 'living',
    price: 139.00,
    priceFormatted: '$139.00',
    leaseSafeBadge: 'Spill & Stash Proof',
    amazonAsin: 'B0BG8R34T2',
    rating: 4.9,
    reviewCount: 5120,
    rentalFeature: 'Conceals stained rental carpet while protecting it from future pet and coffee spills.',
    thumbnail: 'washable-rug'
  },
  {
    id: 'tension-rod-linen',
    title: 'Heavy Duty 43-120" Spring-Loaded Tension Curtain Rod (Matte Black)',
    category: 'living',
    price: 24.99,
    priceFormatted: '$24.99',
    leaseSafeBadge: 'Zero Drilling Required',
    amazonAsin: 'B07V6T9Y4M',
    rating: 4.8,
    reviewCount: 8430,
    rentalFeature: 'Holds up to 30 lbs of blackout drapes with rubber wall grips. Zero drywall holes.',
    thumbnail: 'tension-rod'
  },
  {
    id: 'plugin-arched-lamp',
    title: '2700K Dimmable Minimalist Arched Plug-In Floor Lamp with Woven Linen Shade',
    category: 'lighting',
    price: 89.95,
    priceFormatted: '$89.95',
    leaseSafeBadge: 'No Hardwiring Needed',
    amazonAsin: 'B09KG82P3N',
    rating: 4.9,
    reviewCount: 2210,
    rentalFeature: 'Replaces harsh rental overhead boob lights with soft golden-hour ambient glow.',
    thumbnail: 'arched-lamp'
  },
  {
    id: 'command-frame-strips',
    title: 'Command Large Picture Hanging Strips Value Pack (16 Pairs, 16 lb capacity)',
    category: 'decor',
    price: 14.49,
    priceFormatted: '$14.49',
    leaseSafeBadge: 'Deposit Guardian',
    amazonAsin: 'B073XR4X72',
    rating: 4.9,
    reviewCount: 42900,
    rentalFeature: 'Click-lock gallery wall mount. Removes cleanly with the signature stretch tab.',
    thumbnail: 'command-strips'
  },
  {
    id: 'botanical-wallpaper',
    title: 'Subtle Japandi Linen Weave Removable Peel & Stick Wallpaper Roll',
    category: 'bathroom',
    price: 32.99,
    priceFormatted: '$32.99',
    leaseSafeBadge: 'Steam & Moisture Safe',
    amazonAsin: 'B08F9X14PL',
    rating: 4.7,
    reviewCount: 1640,
    rentalFeature: 'Breathable vinyl that withstands bathroom steam without peeling edges early.',
    thumbnail: 'peel-wallpaper'
  },
  {
    id: 'tension-storage-shelf',
    title: 'Floor-to-Ceiling Adjustable Tension Plant & Towel Ladder Rack',
    category: 'bathroom',
    price: 49.99,
    priceFormatted: '$49.99',
    leaseSafeBadge: 'Expandable Pressure Mount',
    amazonAsin: 'B09T4W21LL',
    rating: 4.8,
    reviewCount: 1120,
    rentalFeature: 'Adds 4 tiers of vertical storage over toilet without touching a screw.',
    thumbnail: 'tension-shelf'
  }
];

/**
 * Builds an FTC-compliant Amazon Affiliate URL with the required tag
 */
export function buildAmazonAffiliateUrl(asinOrUrl: string): string {
  const cleanAsin = asinOrUrl.replace(/^https?:\/\/[^/]+\//, '').replace(/[/?].*$/, '');
  const baseUrl = asinOrUrl.startsWith('http')
    ? asinOrUrl
    : `https://www.amazon.com/dp/${cleanAsin}`;

  try {
    const url = new URL(baseUrl);
    url.searchParams.set('tag', AFFILIATE_TAG);
    return url.toString();
  } catch {
    // If not a parseable URL, format fallback
    const separator = baseUrl.includes('?') ? '&' : '?';
    return `${baseUrl}${separator}tag=${AFFILIATE_TAG}`;
  }
}

/**
 * Disposable email blacklist for ZeroBounce simulation
 */
const DISPOSABLE_DOMAINS = new Set([
  'mailinator.com',
  'tempmail.com',
  '10minutemail.com',
  'guerrillamail.com',
  'yopmail.com',
  'throwawaymail.com',
  'trashmail.com',
  'dispostable.com',
  'sharklasers.com',
  'fakeinbox.com',
  'getairmail.com',
  'temp-mail.org'
]);

export interface EmailValidationResult {
  valid: boolean;
  isDisposable: boolean;
  message?: string;
}

/**
 * Validates email with ZeroBounce disposable email rules
 */
export function validateEmailWithZeroBounce(email: string): EmailValidationResult {
  if (!email || typeof email !== 'string') {
    return { valid: false, isDisposable: false, message: 'Email is required.' };
  }

  const trimmed = email.trim().toLowerCase();
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  if (!emailRegex.test(trimmed)) {
    return { valid: false, isDisposable: false, message: 'Please enter a valid email address.' };
  }

  const domain = trimmed.split('@')[1];
  if (DISPOSABLE_DOMAINS.has(domain)) {
    return {
      valid: false,
      isDisposable: true,
      message: 'Disposable or temporary email addresses are not accepted. Please use your permanent email to receive your design specs.'
    };
  }

  return { valid: true, isDisposable: false };
}

/**
 * Compiles prompt with strict ControlNet depth & renter guardrails
 */
export function compileDesignPrompt(params: {
  roomType: string;
  styleId: string;
  activePresetIds: string[];
  userPrompt?: string;
}): {
  positivePrompt: string;
  negativePrompt: string;
  controlNetConfig: {
    model: string;
    preprocessor: string;
    conditioningScale: number;
    guidanceScale: number;
    depthThreshold: number;
  };
} {
  const style = STYLES[params.styleId] || STYLES.japandi;
  
  const presetEnhancements = params.activePresetIds
    .map(id => RENTER_PRESETS[id]?.promptEnhancement)
    .filter(Boolean)
    .join(', ');

  const userAdditions = params.userPrompt?.trim() ? `, ${params.userPrompt.trim()}` : '';

  const positivePrompt = [
    `High-end interior design makeover of a rental ${params.roomType}.`,
    style.promptKeywords,
    presetEnhancements,
    userAdditions,
    POSITIVE_RENTER_PROMPT
  ].filter(Boolean).join(' ');

  const negativePrompt = NEGATIVE_RENTER_PROMPT;

  return {
    positivePrompt,
    negativePrompt,
    controlNetConfig: {
      model: 'fal-ai/flux-general/controlnet-depth',
      preprocessor: 'depth_midas',
      conditioningScale: 0.88,
      guidanceScale: 3.5,
      depthThreshold: 0.0
    }
  };
}

/**
 * Programmatic SEO (pSEO) Route definition & metadata resolver
 */
export interface PseoMetadata {
  slug: string;
  room: string;
  style: string;
  technique: string;
  h1Title: string;
  subheadline: string;
  depositSafetyScore: number;
  estimatedBudget: string;
  faqs: Array<{ question: string; answer: string }>;
}

export const PSEO_ROUTES: PseoMetadata[] = [
  {
    slug: '/makeover/kitchen/japandi/peel-and-stick',
    room: 'kitchen',
    style: 'japandi',
    technique: 'peel-and-stick',
    h1Title: '90s Honey-Oak Rental Kitchen to Japandi Sanctuary (100% Peel-and-Stick)',
    subheadline: 'How to wrap dated oak cabinets in matte architectural vinyl and apply removable marble backsplash without losing a cent of your deposit.',
    depositSafetyScore: 100,
    estimatedBudget: '$85 – $140 total',
    faqs: [
      {
        question: 'Will peel-and-stick vinyl strip the varnish off my rental cabinets upon move-out?',
        answer: 'No. Modern architectural vinyl films use pressure-sensitive acrylic adhesive rather than permanent solvent glue. When warmed with a standard hair dryer for 15 seconds during move-out, the film releases cleanly leaving zero sticky residue.'
      },
      {
        question: 'Is peel-and-stick backsplash fire-safe behind a gas stove?',
        answer: 'Yes, when installed with a 2-inch clearance from direct open flames or using aluminum-core heat shields. Our recommended tiles are UL94 fire-retardant certified.'
      },
      {
        question: 'What do I do with the original cabinet hardware?',
        answer: 'Store the original knobs and screws in a labeled ziplock bag inside a kitchen drawer. Install modern matte black or brass pulls, and swap the originals back in 15 minutes before your final walk-through.'
      }
    ]
  },
  {
    slug: '/makeover/living/organic-modern/hide-carpet',
    room: 'living',
    style: 'organic-modern',
    technique: 'hide-carpet',
    h1Title: 'Conceal Stained Rental Carpet with an Organic Modern Layered Rug System',
    subheadline: 'The renter-proven guide to anchoring an oversized 9x12 washable rug over builder-grade carpet without bunching or shifting.',
    depositSafetyScore: 100,
    estimatedBudget: '$140 – $220 total',
    faqs: [
      {
        question: 'How do you stop an area rug from bubbling on top of wall-to-wall carpet?',
        answer: 'Use a dual-surface carpet-to-rug non-slip pad (polyester felt with rubber backing). It locks the fibers together and eliminates carpet ripple friction completely.'
      },
      {
        question: 'Will a heavy sofa crush the existing carpet fibers permanently?',
        answer: 'Place furniture coaster pads under heavy legs. If any indentations remain at move-out, place an ice cube on the dent, let it melt, and gently fluff the fibers with a fork.'
      }
    ]
  },
  {
    slug: '/makeover/bedroom/quiet-luxury/zero-drill-lighting',
    room: 'bedroom',
    style: 'quiet-luxury',
    technique: 'zero-drill-lighting',
    h1Title: 'Zero-Drill Bedroom Upgrade: Replace the "Boob Light" with Warm 2700K Sconces',
    subheadline: 'Elevate dark rental bedrooms with plug-in arched lamps, tension drapery, and Command-mounted museum prints.',
    depositSafetyScore: 100,
    estimatedBudget: '$95 – $180 total',
    faqs: [
      {
        question: 'How do Command Picture Hanging Strips support large frames safely?',
        answer: 'Four pairs of large Command strips hold up to 16 lbs. Always clean the drywall with isopropyl alcohol first, press firmly for 30 seconds, and allow 1 hour of adhesive cure time before mounting the artwork.'
      },
      {
        question: 'Can I swap the landlord overhead ceiling fixture?',
        answer: 'We recommend leaving the ceiling fixture switched off and using plug-in wall sconces with cord concealers or a floor switch. No electrical rewiring, zero landlord liability.'
      }
    ]
  },
  {
    slug: '/makeover/bathroom/warm-minimalist/removable-wallpaper',
    room: 'bathroom',
    style: 'japandi',
    technique: 'removable-wallpaper',
    h1Title: 'High-Humidity Rental Bathroom Glow-Up with Removable Wallpaper & Tension Racks',
    subheadline: 'Transform sterile white tile into a Japanese spa oasis using steam-rated vinyl wallpaper and vertical pressure shelves.',
    depositSafetyScore: 100,
    estimatedBudget: '$60 – $110 total',
    faqs: [
      {
        question: 'Will bathroom shower steam make peel-and-stick wallpaper peel off prematurely?',
        answer: 'Only if cheap paper-backed contact paper is used. We recommend steam-rated woven polyester vinyl with moisture barrier ratings, which adheres reliably through hundreds of hot showers and peels off in one sheet.'
      }
    ]
  }
];

export function resolvePseoRoute(slug: string): PseoMetadata {
  const match = PSEO_ROUTES.find(r => r.slug === slug);
  return match || PSEO_ROUTES[0];
}
