import React, { useState } from 'react';
import { ArrowRight, ShieldCheck, Sparkles, Check, Zap, Lock, DollarSign } from 'lucide-react';
import { RoomCanvasVisualizer } from './RoomCanvasVisualizer';

interface HeroSectionProps {
  onStartMakeover: () => void;
  onExplorePresets: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onStartMakeover,
  onExplorePresets
}) => {
  const [selectedDemoScene, setSelectedDemoScene] = useState<'kitchen' | 'living'>('kitchen');

  return (
    <section className="relative w-full pt-12 pb-20 px-6 overflow-hidden bg-grain">
      {/* Ambient 2700K golden-hour lighting gradients in background */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[550px] bg-gradient-to-b from-[#C69C6D]/15 via-[#F0ECE1]/30 to-transparent blur-3xl pointer-events-none -z-10" />
      <div className="absolute top-20 right-10 w-[400px] h-[400px] bg-[#6E7864]/10 rounded-full blur-3xl pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto flex flex-col items-center">
        {/* Editorial Eyebrow Notice */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FAF8F5] border border-[#B8B2A6]/40 text-xs font-medium text-[#4A3B32] shadow-xs mb-6">
          <Sparkles className="w-3.5 h-3.5 text-[#C69C6D]" />
          <span>Engineered for America's 46.1 Million Renter Households</span>
          <span className="text-[#8C8275]">·</span>
          <span className="text-[#6E7864] font-semibold">100% Lease-Safe</span>
        </div>

        {/* Main Headline & Subheadline */}
        <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-serif font-bold text-[#2C2724] text-center tracking-tight leading-[1.1] max-w-4xl text-balance">
          Transform Your Rental. <br className="hidden sm:inline" />
          <span className="italic font-normal text-[#4A3B32]">Keep Your Deposit.</span>
        </h1>

        <p className="mt-6 text-base sm:text-lg md:text-xl text-[#655E56] text-center max-w-2xl leading-relaxed text-balance">
          The first AI interior studio engineered with strict no-drill, peel-and-stick, and zero-structural-damage constraints. Turn ugly apartment baselines into quiet luxury without losing a cent.
        </p>

        {/* Action Buttons */}
        <div className="mt-8 flex flex-col sm:flex-row items-center gap-4">
          <button
            onClick={onStartMakeover}
            className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-[#4A3B32] hover:bg-[#382C25] text-[#FAF8F5] font-semibold text-sm shadow-md hover:shadow-lg transition-all active:scale-98 flex items-center justify-center gap-2 cursor-pointer group"
          >
            <span>Start Free Makeover (Zero CAD)</span>
            <ArrowRight className="w-4 h-4 text-[#C69C6D] group-hover:translate-x-1 transition-transform" />
          </button>
          
          <button
            onClick={onExplorePresets}
            className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-[#FAF8F5] hover:bg-[#F0ECE1] text-[#4A3B32] font-semibold text-sm border border-[#B8B2A6]/50 shadow-xs transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <span>Explore Baseline Fixes</span>
          </button>
        </div>

        {/* Scene Selector Tabs for Hero Visualizer */}
        <div className="mt-12 flex items-center gap-2 p-1 rounded-xl bg-[#EFECE6] border border-[#B8B2A6]/40">
          <button
            onClick={() => setSelectedDemoScene('kitchen')}
            className={`px-4 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
              selectedDemoScene === 'kitchen'
                ? 'bg-[#FAF8F5] text-[#2C2724] shadow-xs'
                : 'text-[#655E56] hover:text-[#2C2724]'
            }`}
          >
            1990s Honey-Oak Kitchen → Warm Japandi
          </button>
          <button
            onClick={() => setSelectedDemoScene('living')}
            className={`px-4 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
              selectedDemoScene === 'living'
                ? 'bg-[#FAF8F5] text-[#2C2724] shadow-xs'
                : 'text-[#655E56] hover:text-[#2C2724]'
            }`}
          >
            Stained Rental Carpet → Layered Organic Modern
          </button>
        </div>

        {/* 3D Modern Hero Card with Auto-Gliding Before/After Visualizer */}
        <div className="mt-4 w-full max-w-5xl perspective-1000">
          <div className="transform transition-transform duration-500 rounded-2xl p-2 sm:p-3 bg-[#FAF8F5]/80 backdrop-blur-xl border border-[#B8B2A6]/40 shadow-2xl glow-golden-hour">
            <RoomCanvasVisualizer
              sceneId={selectedDemoScene}
              styleName={selectedDemoScene === 'kitchen' ? 'Warm Japandi' : 'Organic Modern'}
              autoGlideDefault={true}
              showDepthMapLock={true}
              customOverlayText="Slide or let Auto-Glide reveal peel-and-stick transformation"
            />
          </div>
        </div>

        {/* Competitor-Informed Product Guardrails (Why We Win) */}
        <div className="mt-16 w-full max-w-5xl">
          <div className="text-center mb-8">
            <span className="text-xs font-mono tracking-widest text-[#8C8275] uppercase">
              Competitor-Informed Product Guardrails
            </span>
            <h2 className="text-2xl sm:text-3xl font-serif font-bold text-[#2C2724] mt-1">
              Why American Renters Win with Eden Canvas
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Guardrail 1: Zero CAD Complexity */}
            <div className="p-6 rounded-2xl bg-[#FAF8F5] border border-[#B8B2A6]/40 shadow-xs flex flex-col justify-between">
              <div>
                <div className="w-10 h-10 rounded-xl bg-[#C69C6D]/15 text-[#4A3B32] flex items-center justify-center mb-4">
                  <Zap className="w-5 h-5 text-[#C69C6D]" />
                </div>
                <div className="flex items-center gap-2 mb-2">
                  <h3 className="font-serif text-lg font-bold text-[#2C2724]">Zero CAD Complexity</h3>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-[#4A3B32]/10 text-[#4A3B32] font-semibold">
                    Beats Planner 5D
                  </span>
                </div>
                <p className="text-xs text-[#655E56] leading-relaxed">
                  No tedious 60-minute floor plan measuring or 3D polygon modeling. Upload 1 phone snapshot and receive photorealistic lease-safe restyling in under 10 seconds.
                </p>
              </div>
              <div className="mt-4 pt-4 border-t border-[#B8B2A6]/30 flex items-center gap-2 text-xs font-semibold text-[#6E7864]">
                <Check className="w-4 h-4" /> Instant 10-Second Generation
              </div>
            </div>

            {/* Guardrail 2: Strict Structural Lock */}
            <div className="p-6 rounded-2xl bg-[#FAF8F5] border border-[#B8B2A6]/40 shadow-xs flex flex-col justify-between">
              <div>
                <div className="w-10 h-10 rounded-xl bg-[#6E7864]/15 text-[#4A3B32] flex items-center justify-center mb-4">
                  <Lock className="w-5 h-5 text-[#6E7864]" />
                </div>
                <div className="flex items-center gap-2 mb-2">
                  <h3 className="font-serif text-lg font-bold text-[#2C2724]">Strict Structural Lock</h3>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-[#6E7864]/10 text-[#6E7864] font-semibold">
                    Beats RoomGPT
                  </span>
                </div>
                <p className="text-xs text-[#655E56] leading-relaxed">
                  Our ControlNet Depth pipeline hard-locks existing walls, windows, and door frames. AI will NEVER hallucinate knocked-down load-bearing walls that forfeit your deposit.
                </p>
              </div>
              <div className="mt-4 pt-4 border-t border-[#B8B2A6]/30 flex items-center gap-2 text-xs font-semibold text-[#6E7864]">
                <ShieldCheck className="w-4 h-4" /> Zero-Drill Guarantee
              </div>
            </div>

            {/* Guardrail 3: No Hard Paywall Upfront */}
            <div className="p-6 rounded-2xl bg-[#FAF8F5] border border-[#B8B2A6]/40 shadow-xs flex flex-col justify-between">
              <div>
                <div className="w-10 h-10 rounded-xl bg-[#4A3B32]/10 text-[#4A3B32] flex items-center justify-center mb-4">
                  <DollarSign className="w-5 h-5 text-[#4A3B32]" />
                </div>
                <div className="flex items-center gap-2 mb-2">
                  <h3 className="font-serif text-lg font-bold text-[#2C2724]">No Subscription Trap</h3>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-[#C69C6D]/20 text-[#4A3B32] font-semibold">
                    Beats InteriorAI
                  </span>
                </div>
                <p className="text-xs text-[#655E56] leading-relaxed">
                  Say goodbye to $29/mo predatory recurring credit-card charges. Enjoy 5 free credits on email verification, followed by affordable one-time credit packs starting at $4.99.
                </p>
              </div>
              <div className="mt-4 pt-4 border-t border-[#B8B2A6]/30 flex items-center gap-2 text-xs font-semibold text-[#6E7864]">
                <Check className="w-4 h-4" /> 5 Free Credits Upfront
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
