import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Lock, Sparkles, CheckCircle2, ShieldCheck, Play, Pause } from 'lucide-react';

export type RoomSceneId = 'kitchen' | 'living' | 'bathroom' | 'bedroom';

interface RoomCanvasVisualizerProps {
  sceneId: RoomSceneId;
  styleName?: string;
  isGenerating?: boolean;
  isBlurred?: boolean;
  autoGlideDefault?: boolean;
  showDepthMapLock?: boolean;
  customOverlayText?: string;
}

export const RoomCanvasVisualizer: React.FC<RoomCanvasVisualizerProps> = ({
  sceneId,
  styleName = 'Japandi',
  isGenerating = false,
  isBlurred = false,
  autoGlideDefault = false,
  showDepthMapLock = true,
  customOverlayText
}) => {
  const [sliderPosition, setSliderPosition] = useState<number>(50); // percentage 0 to 100
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [isAutoGliding, setIsAutoGliding] = useState<boolean>(autoGlideDefault);
  const containerRef = useRef<HTMLDivElement>(null);
  const glideDirection = useRef<number>(1); // 1 = right, -1 = left

  // Auto-glide animation when enabled
  useEffect(() => {
    if (!isAutoGliding || isDragging) return;

    const interval = setInterval(() => {
      setSliderPosition(prev => {
        let next = prev + 0.35 * glideDirection.current;
        if (next >= 85) {
          glideDirection.current = -1;
          next = 85;
        } else if (next <= 15) {
          glideDirection.current = 1;
          next = 15;
        }
        return next;
      });
    }, 24);

    return () => clearInterval(interval);
  }, [isAutoGliding, isDragging]);

  const handlePointerDown = (e: React.PointerEvent) => {
    setIsDragging(true);
    setIsAutoGliding(false);
    updateSlider(e.clientX);
  };

  const handlePointerMove = useCallback((e: PointerEvent) => {
    if (!isDragging) return;
    updateSlider(e.clientX);
  }, [isDragging]);

  const handlePointerUp = useCallback(() => {
    setIsDragging(false);
  }, []);

  useEffect(() => {
    if (isDragging) {
      window.addEventListener('pointermove', handlePointerMove);
      window.addEventListener('pointerup', handlePointerUp);
    }
    return () => {
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerup', handlePointerUp);
    };
  }, [isDragging, handlePointerMove, handlePointerUp]);

  const updateSlider = (clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = clientX - rect.left;
    const percentage = Math.max(0, Math.min(100, (x / rect.width) * 100));
    setSliderPosition(percentage);
  };

  return (
    <div className="relative w-full overflow-hidden rounded-2xl bg-[#2C2724] shadow-2xl select-none group border border-[#B8B2A6]/30">
      {/* Top HUD Badges */}
      <div className="absolute top-4 left-4 right-4 z-30 flex flex-wrap items-center justify-between gap-2 pointer-events-none">
        {showDepthMapLock && (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#2C2724]/90 backdrop-blur-md border border-[#C69C6D]/40 text-[11px] font-medium text-[#FAF8F5] tracking-wide pointer-events-auto shadow-sm">
            <Lock className="w-3.5 h-3.5 text-[#C69C6D]" />
            <span className="text-[#C69C6D] font-semibold">ControlNet Geometry Lock:</span>
            <span>ACTIVE · Depth Delta: 0.00%</span>
          </div>
        )}

        <div className="flex items-center gap-2 pointer-events-auto">
          <button
            onClick={() => setIsAutoGliding(!isAutoGliding)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#FAF8F5]/90 hover:bg-[#FAF8F5] backdrop-blur-md text-[#2C2724] text-[11px] font-medium transition-all shadow-sm border border-[#B8B2A6]/40 cursor-pointer"
            title="Toggle auto-glide preview"
            aria-label={isAutoGliding ? "Pause auto-glide" : "Play auto-glide"}
          >
            {isAutoGliding ? <Pause className="w-3 h-3 text-[#4A3B32]" /> : <Play className="w-3 h-3 text-[#4A3B32]" />}
            <span>{isAutoGliding ? 'Pause Glide' : 'Auto Glide'}</span>
          </button>

          <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-full bg-[#6E7864]/90 text-[#FAF8F5] text-[11px] font-medium">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-300" />
            <span>100% Deposit Safe</span>
          </div>
        </div>
      </div>

      {/* Main Visualizer Area */}
      <div
        ref={containerRef}
        onPointerDown={handlePointerDown}
        className={`relative w-full aspect-[16/9] min-h-[340px] max-h-[640px] cursor-ew-resize overflow-hidden ${
          isBlurred ? 'filter blur-xl scale-105 transition-all duration-700' : ''
        }`}
      >
        {/* AFTER LAYER (Full background layer) */}
        <div className="absolute inset-0 w-full h-full">
          <RenderAfterScene sceneId={sceneId} styleName={styleName} />
          {/* Subtle After Label */}
          <div className="absolute bottom-4 right-4 z-10 px-3 py-1 rounded bg-[#2C2724]/80 backdrop-blur-sm text-[11px] font-medium tracking-wider text-[#FAF8F5] uppercase border border-[#C69C6D]/30 pointer-events-none">
            Eden Canvas: {styleName} (Peel & Stick)
          </div>
        </div>

        {/* BEFORE LAYER (Clipped overlay on the left) */}
        <div
          className="absolute inset-0 h-full overflow-hidden"
          style={{ width: `${sliderPosition}%` }}
        >
          <div
            className="absolute inset-0 h-full"
            style={{ width: containerRef.current ? `${containerRef.current.clientWidth}px` : '100%' }}
          >
            <RenderBeforeScene sceneId={sceneId} />
            {/* Subtle Before Label */}
            <div className="absolute bottom-4 left-4 z-10 px-3 py-1 rounded bg-[#2C2724]/80 backdrop-blur-sm text-[11px] font-medium tracking-wider text-[#FAF8F5]/90 uppercase border border-white/10 pointer-events-none">
              Baseline Rental (Original)
            </div>
          </div>
        </div>

        {/* SLIDER DIVIDER LINE & HANDLE */}
        <div
          className="absolute top-0 bottom-0 z-20 w-0.5 bg-white/90 shadow-[0_0_12px_rgba(0,0,0,0.5)] cursor-ew-resize pointer-events-none"
          style={{ left: `${sliderPosition}%` }}
        >
          <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-9 h-9 rounded-full bg-[#FAF8F5] text-[#2C2724] border-2 border-[#4A3B32] shadow-xl flex items-center justify-center transition-transform hover:scale-110 pointer-events-auto cursor-ew-resize">
            <div className="flex items-center gap-0.5 text-[#4A3B32]">
              <span className="text-[10px] font-bold">◀</span>
              <span className="text-[10px] font-bold">▶</span>
            </div>
          </div>
        </div>

        {/* Custom Overlay Text if specified */}
        {customOverlayText && (
          <div className="absolute bottom-14 left-1/2 -translate-x-1/2 z-20 px-4 py-1.5 rounded-full bg-[#2C2724]/90 text-[#FAF8F5] text-xs font-medium backdrop-blur-md border border-[#C69C6D]/40 shadow-lg">
            {customOverlayText}
          </div>
        )}

        {/* Generating Overlay Animation */}
        {isGenerating && (
          <div className="absolute inset-0 z-40 bg-[#2C2724]/75 backdrop-blur-md flex flex-col items-center justify-center text-[#FAF8F5] p-6 text-center">
            <div className="relative w-16 h-16 mb-4">
              <div className="absolute inset-0 rounded-full border-2 border-[#C69C6D]/30 animate-ping" />
              <div className="absolute inset-0 rounded-full border-2 border-[#C69C6D] border-t-transparent animate-spin" />
              <div className="absolute inset-0 flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-[#C69C6D]" />
              </div>
            </div>
            <p className="font-serif text-xl font-medium tracking-wide text-[#FAF8F5]">
              Synthesizing Zero-Damage Makeover...
            </p>
            <p className="text-xs text-[#B8B2A6] mt-1 max-w-sm">
              Extracting 3D geometry depth map & locking structural boundaries
            </p>
          </div>
        )}
      </div>

      {/* Bottom Spec Footer Bar */}
      <div className="px-5 py-3 bg-[#241F1C] border-t border-[#4A3B32]/40 flex flex-wrap items-center justify-between gap-3 text-xs text-[#B8B2A6]">
        <div className="flex items-center gap-3">
          <span className="text-[#FAF8F5] font-medium">Verified Constraints:</span>
          <span className="flex items-center gap-1 text-emerald-400">
            <CheckCircle2 className="w-3.5 h-3.5" /> 0 Drills
          </span>
          <span className="flex items-center gap-1 text-emerald-400">
            <CheckCircle2 className="w-3.5 h-3.5" /> 0 Wall Tears
          </span>
          <span className="flex items-center gap-1 text-emerald-400">
            <CheckCircle2 className="w-3.5 h-3.5" /> 100% Removable
          </span>
        </div>
        <div className="text-[11px] text-[#C69C6D]">
          Drag slider or click 'Auto Glide' to inspect architectural transitions
        </div>
      </div>
    </div>
  );
};

/**
 * High-craft visual rendering of the BEFORE rental scene (dated baseline)
 */
const RenderBeforeScene: React.FC<{ sceneId: RoomSceneId }> = ({ sceneId }) => {
  switch (sceneId) {
    case 'kitchen':
      return (
        <svg className="w-full h-full object-cover" viewBox="0 0 1200 675" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
          {/* Background wall: sterile rental off-white with slight yellow tinge */}
          <rect width="1200" height="675" fill="#E8E4D9" />
          
          {/* Ceiling with harsh fluorescent fixture shadow */}
          <rect width="1200" height="90" fill="#DCD7CA" />
          {/* Fluorescent fixture */}
          <rect x="420" y="25" width="360" height="40" rx="4" fill="#F0EDE4" stroke="#8C887B" strokeWidth="2" />
          <line x1="440" y1="45" x2="760" y2="45" stroke="#FFF" strokeWidth="8" strokeLinecap="round" opacity="0.9" />
          
          {/* Back wall rental window with plastic vertical blinds */}
          <rect x="780" y="110" width="340" height="280" fill="#BFD4DC" stroke="#7A7568" strokeWidth="4" />
          {/* Vertical blinds slats */}
          {Array.from({ length: 14 }).map((_, i) => (
            <rect key={i} x={790 + i * 23} y={115} width="16" height="270" fill="#E4E0D2" stroke="#B8B3A2" strokeWidth="1" />
          ))}

          {/* 90s Honey-Oak Upper Cabinets */}
          <g>
            {/* Upper cabinets body */}
            <rect x="80" y="100" width="620" height="240" fill="#B87333" stroke="#8A4B1A" strokeWidth="4" />
            {/* Cabinet doors honey oak grain panels */}
            <rect x="95" y="115" width="135" height="210" fill="#C9823E" stroke="#8A4B1A" strokeWidth="3" />
            <rect x="110" y="130" width="105" height="180" fill="#B06E2E" stroke="#7A3F12" strokeWidth="2" />
            {/* Brass round knob */}
            <circle cx="215" cy="220" r="6" fill="#D4AF37" stroke="#735C14" strokeWidth="1.5" />

            <rect x="245" y="115" width="135" height="210" fill="#C9823E" stroke="#8A4B1A" strokeWidth="3" />
            <rect x="260" y="130" width="105" height="180" fill="#B06E2E" stroke="#7A3F12" strokeWidth="2" />
            <circle cx="260" cy="220" r="6" fill="#D4AF37" stroke="#735C14" strokeWidth="1.5" />

            <rect x="395" y="115" width="135" height="210" fill="#C9823E" stroke="#8A4B1A" strokeWidth="3" />
            <rect x="410" y="130" width="105" height="180" fill="#B06E2E" stroke="#7A3F12" strokeWidth="2" />
            <circle cx="515" cy="220" r="6" fill="#D4AF37" stroke="#735C14" strokeWidth="1.5" />

            <rect x="545" y="115" width="135" height="210" fill="#C9823E" stroke="#8A4B1A" strokeWidth="3" />
            <rect x="560" y="130" width="105" height="180" fill="#B06E2E" stroke="#7A3F12" strokeWidth="2" />
            <circle cx="560" cy="220" r="6" fill="#D4AF37" stroke="#735C14" strokeWidth="1.5" />
          </g>

          {/* Builder-grade plain laminate backsplash */}
          <rect x="80" y="340" width="1040" height="90" fill="#D8D2C2" stroke="#ABA494" strokeWidth="2" />
          {/* Wall outlet */}
          <rect x="340" y="365" width="30" height="42" rx="3" fill="#E8E3D5" stroke="#999" strokeWidth="1.5" />
          <circle cx="355" cy="378" r="3" fill="#444" />
          <circle cx="355" cy="394" r="3" fill="#444" />

          {/* Generic laminate countertop */}
          <rect x="60" y="430" width="1080" height="35" fill="#BFB59F" stroke="#7A705B" strokeWidth="3" />

          {/* Lower 90s Honey-Oak Cabinets & Drawers */}
          <rect x="80" y="465" width="1040" height="180" fill="#B87333" stroke="#8A4B1A" strokeWidth="4" />
          {/* Lower cabinet panels */}
          <rect x="100" y="480" width="180" height="150" fill="#C9823E" stroke="#8A4B1A" strokeWidth="3" />
          <circle cx="260" cy="510" r="6" fill="#D4AF37" />
          
          <rect x="300" y="480" width="180" height="150" fill="#C9823E" stroke="#8A4B1A" strokeWidth="3" />
          <circle cx="320" cy="510" r="6" fill="#D4AF37" />

          <rect x="500" y="480" width="180" height="150" fill="#C9823E" stroke="#8A4B1A" strokeWidth="3" />
          <circle cx="660" cy="510" r="6" fill="#D4AF37" />

          {/* Dated vinyl 12x12 tile floor */}
          <rect x="0" y="620" width="1200" height="55" fill="#C7BFA8" />
          {Array.from({ length: 12 }).map((_, i) => (
            <line key={i} x1={i * 100} y1="620" x2={i * 100} y2="675" stroke="#948D79" strokeWidth="2" />
          ))}

          {/* Harsh cool overhead glare filter */}
          <rect width="1200" height="675" fill="rgba(200, 215, 230, 0.08)" />
        </svg>
      );

    case 'living':
      return (
        <svg className="w-full h-full object-cover" viewBox="0 0 1200 675" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
          {/* Background wall */}
          <rect width="1200" height="675" fill="#ECE7DC" />
          {/* Ceiling with boob light */}
          <rect width="1200" height="80" fill="#DCD6C7" />
          {/* Classic "Boob light" */}
          <circle cx="600" cy="80" r="32" fill="#FFF5DC" stroke="#8C7A6B" strokeWidth="3" />
          <circle cx="600" cy="98" r="5" fill="#B38F48" />

          {/* Bare walls with small nail holes */}
          <circle cx="380" cy="260" r="2.5" fill="#7A6F62" />
          <circle cx="780" cy="240" r="2.5" fill="#7A6F62" />

          {/* Standard rental window with dirty plastic vertical blinds */}
          <rect x="200" y="130" width="380" height="290" fill="#BCD0DA" stroke="#8C8375" strokeWidth="4" />
          {Array.from({ length: 15 }).map((_, i) => (
            <rect key={i} x={210 + i * 24} y={135} width="16" height="280" fill="#E4DED0" stroke="#BBB19F" strokeWidth="1" />
          ))}

          {/* Ugly stained beige rental carpet */}
          <rect x="0" y="440" width="1200" height="235" fill="#C5B79F" />
          {/* Subtle carpet wear/stains */}
          <ellipse cx="600" cy="540" rx="140" ry="35" fill="#B3A48C" opacity="0.6" />
          <ellipse cx="380" cy="580" rx="90" ry="20" fill="#B0A087" opacity="0.5" />
          <ellipse cx="880" cy="520" rx="80" ry="25" fill="#B5A68E" opacity="0.5" />

          {/* Cheap generic sofa */}
          <rect x="520" y="360" width="460" height="150" rx="8" fill="#6A6258" />
          <rect x="550" y="330" width="400" height="80" rx="6" fill="#585148" />
        </svg>
      );

    case 'bathroom':
      return (
        <svg className="w-full h-full object-cover" viewBox="0 0 1200 675" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
          <rect width="1200" height="675" fill="#E5E0D4" />
          {/* Sterile white tile wall with dirty yellow grout */}
          {Array.from({ length: 15 }).map((_, r) =>
            Array.from({ length: 24 }).map((_, c) => (
              <rect key={`${r}-${c}`} x={c * 50} y={r * 45} width="48" height="43" fill="#F4F1EA" stroke="#C5BBA7" strokeWidth="1.5" />
            ))
          )}
          {/* Frameless plain plate mirror glued to wall */}
          <rect x="360" y="110" width="480" height="300" fill="#BFD6E0" stroke="#999" strokeWidth="2" opacity="0.9" />
          {/* 3-bulb vanity bar */}
          <rect x="420" y="70" width="360" height="25" fill="#D0D0D0" stroke="#777" strokeWidth="2" />
          <circle cx="480" cy="82" r="14" fill="#FFFBE6" stroke="#999" />
          <circle cx="600" cy="82" r="14" fill="#FFFBE6" stroke="#999" />
          <circle cx="720" cy="82" r="14" fill="#FFFBE6" stroke="#999" />
          {/* Standard chrome faucet & white pedestal */}
          <rect x="480" y="430" width="240" height="40" rx="6" fill="#FFFFFF" stroke="#AAA" strokeWidth="2" />
        </svg>
      );

    case 'bedroom':
      return (
        <svg className="w-full h-full object-cover" viewBox="0 0 1200 675" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
          <rect width="1200" height="675" fill="#E8E4DA" />
          <rect x="0" y="450" width="1200" height="225" fill="#C2B59F" />
          <circle cx="600" cy="70" r="30" fill="#FFF3D4" stroke="#887865" strokeWidth="3" />
          <rect x="320" y="320" width="560" height="220" rx="6" fill="#8C8477" />
          <rect x="350" y="270" width="500" height="90" rx="4" fill="#5E584F" />
        </svg>
      );
  }
};

/**
 * High-craft visual rendering of the AFTER transformed room (Quiet Luxury / Japandi Zero-Damage)
 */
const RenderAfterScene: React.FC<{ sceneId: RoomSceneId; styleName: string }> = ({ sceneId }) => {
  switch (sceneId) {
    case 'kitchen':
      return (
        <svg className="w-full h-full object-cover" viewBox="0 0 1200 675" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
          <defs>
            {/* Calacatta marble peel-and-stick pattern */}
            <linearGradient id="marbleGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#FAF9F6" />
              <stop offset="50%" stopColor="#F2EFE9" />
              <stop offset="100%" stopColor="#E8E4DB" />
            </linearGradient>
            {/* Warm under-cabinet 2700K lighting glow */}
            <radialGradient id="glow2700k" cx="50%" cy="0%" r="90%">
              <stop offset="0%" stopColor="rgba(255, 228, 179, 0.75)" />
              <stop offset="50%" stopColor="rgba(255, 214, 148, 0.3)" />
              <stop offset="100%" stopColor="rgba(255, 214, 148, 0)" />
            </radialGradient>
            {/* Golden hour window stream */}
            <linearGradient id="goldenHourLight" x1="100%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="rgba(255, 235, 195, 0.45)" />
              <stop offset="60%" stopColor="rgba(255, 220, 160, 0.15)" />
              <stop offset="100%" stopColor="rgba(255, 220, 160, 0)" />
            </linearGradient>
          </defs>

          {/* Background wall in warm serene Japandi Greige */}
          <rect width="1200" height="675" fill="#F4F1EA" />

          {/* Golden hour sunlight ray flowing through window */}
          <polygon points="760,100 1140,100 950,675 420,675" fill="url(#goldenHourLight)" />

          {/* Clean ceiling with recessed architectural track or pendant */}
          <rect width="1200" height="90" fill="#EAE5DA" />
          {/* Minimalist matte black cylinder flush lights */}
          <rect x="360" y="30" width="36" height="26" rx="2" fill="#2C2724" />
          <circle cx="378" cy="56" r="14" fill="#FFF4D6" opacity="0.9" />

          <rect x="620" y="30" width="36" height="26" rx="2" fill="#2C2724" />
          <circle cx="638" cy="56" r="14" fill="#FFF4D6" opacity="0.9" />

          {/* Window updated: Crisp linen roman shade over window */}
          <rect x="780" y="105" width="340" height="290" fill="#C5DCE6" stroke="#4A3B32" strokeWidth="3" />
          {/* Tension rod with Belgian linen soft folding shade */}
          <rect x="770" y="98" width="360" height="12" rx="3" fill="#2C2724" />
          <rect x="780" y="110" width="340" height="90" fill="#E9E4D8" stroke="#CEC6B5" strokeWidth="2" />
          <line x1="780" y1="140" x2="1120" y2="140" stroke="#B8B09F" strokeWidth="2" />
          <line x1="780" y1="170" x2="1120" y2="170" stroke="#B8B09F" strokeWidth="2" />

          {/* Upper Cabinets: TRANSFORMED with Matte Sage & Greige Architectural Vinyl Wrap */}
          <g>
            {/* Cabinet body */}
            <rect x="80" y="100" width="620" height="240" fill="#6E7864" stroke="#4F5647" strokeWidth="2" />
            
            {/* Door 1: Sleek slab door (modern clean lines) */}
            <rect x="90" y="110" width="142" height="220" rx="3" fill="#75806B" stroke="#5E6754" strokeWidth="1.5" />
            {/* Minimalist brushed brass edge pull */}
            <rect x="224" y="210" width="4" height="42" rx="1.5" fill="#C69C6D" stroke="#9E7649" strokeWidth="0.8" />

            {/* Door 2 */}
            <rect x="240" y="110" width="142" height="220" rx="3" fill="#75806B" stroke="#5E6754" strokeWidth="1.5" />
            <rect x="244" y="210" width="4" height="42" rx="1.5" fill="#C69C6D" stroke="#9E7649" strokeWidth="0.8" />

            {/* Door 3 */}
            <rect x="390" y="110" width="142" height="220" rx="3" fill="#75806B" stroke="#5E6754" strokeWidth="1.5" />
            <rect x="524" y="210" width="4" height="42" rx="1.5" fill="#C69C6D" stroke="#9E7649" strokeWidth="0.8" />

            {/* Door 4 */}
            <rect x="540" y="110" width="142" height="220" rx="3" fill="#75806B" stroke="#5E6754" strokeWidth="1.5" />
            <rect x="544" y="210" width="4" height="42" rx="1.5" fill="#C69C6D" stroke="#9E7649" strokeWidth="0.8" />
          </g>

          {/* Under-cabinet 2700K ambient LED glow wash */}
          <rect x="80" y="340" width="620" height="60" fill="url(#glow2700k)" />

          {/* Backsplash: TRANSFORMED with Thickened Calacatta Marble Peel-and-Stick Tiles */}
          <g>
            <rect x="80" y="340" width="1040" height="90" fill="url(#marbleGrad)" stroke="#C7C1B2" strokeWidth="1.5" />
            {/* Fine marble veining paths */}
            <path d="M 120 340 Q 180 370, 240 400 T 320 430" stroke="#B8B2A6" strokeWidth="1.5" fill="none" opacity="0.6" />
            <path d="M 440 340 Q 510 380, 600 395 T 720 430" stroke="#B8B2A6" strokeWidth="1.8" fill="none" opacity="0.7" />
            <path d="M 820 340 Q 890 365, 960 410" stroke="#C69C6D" strokeWidth="1.2" fill="none" opacity="0.5" />
            {/* Sleek matte black outlet cover */}
            <rect x="340" y="365" width="28" height="42" rx="2" fill="#2C2724" stroke="#444" strokeWidth="1" />
            <rect x="348" y="373" width="12" height="8" rx="1" fill="#111" />
            <rect x="348" y="390" width="12" height="8" rx="1" fill="#111" />
          </g>

          {/* Countertop: Clean White Travertine / Quartz look with peel-and-stick film */}
          <rect x="60" y="430" width="1080" height="35" rx="2" fill="#EAE5DB" stroke="#C4BCAB" strokeWidth="1.5" />
          <line x1="60" y1="432" x2="1140" y2="432" stroke="#FFF" strokeWidth="2" opacity="0.8" />

          {/* Countertop Accessories (Staged for Quiet Luxury / Japandi) */}
          {/* Fluted wooden cutting board */}
          <rect x="180" y="385" width="55" height="45" rx="3" fill="#8C6D4F" stroke="#5E4631" strokeWidth="1.5" />
          {/* Handmade ceramic wabi-sabi vase with olive branch */}
          <ellipse cx="640" cy="425" rx="24" ry="12" fill="#D3CBBE" stroke="#998F7F" strokeWidth="1.5" />
          <path d="M 622 425 Q 618 375, 634 360 L 646 360 Q 662 375, 658 425 Z" fill="#E4DDD2" stroke="#998F7F" strokeWidth="1.5" />
          {/* Olive branch stems */}
          <path d="M 640 360 Q 630 310, 610 270" stroke="#4F5647" strokeWidth="2" fill="none" />
          <ellipse cx="608" cy="268" rx="8" ry="4" fill="#6E7864" transform="rotate(-30 608 268)" />
          <ellipse cx="620" cy="295" rx="7" ry="3.5" fill="#6E7864" transform="rotate(-15 620 295)" />
          <ellipse cx="645" cy="320" rx="8" ry="4" fill="#6E7864" transform="rotate(25 645 320)" />

          {/* Lower Cabinets: Soft Warm Greige Vinyl Wrap */}
          <rect x="80" y="465" width="1040" height="180" fill="#B8B2A6" stroke="#8E877B" strokeWidth="2" />
          <rect x="100" y="478" width="180" height="155" rx="3" fill="#C5BFB3" stroke="#9D9689" strokeWidth="1.5" />
          <rect x="272" y="490" width="4" height="36" rx="1" fill="#C69C6D" />

          <rect x="300" y="478" width="180" height="155" rx="3" fill="#C5BFB3" stroke="#9D9689" strokeWidth="1.5" />
          <rect x="304" y="490" width="4" height="36" rx="1" fill="#C69C6D" />

          <rect x="500" y="478" width="180" height="155" rx="3" fill="#C5BFB3" stroke="#9D9689" strokeWidth="1.5" />
          <rect x="672" y="490" width="4" height="36" rx="1" fill="#C69C6D" />

          {/* Floor: Natural pale ash peel-and-stick wood planks */}
          <rect x="0" y="620" width="1200" height="55" fill="#DDD5C7" />
          {Array.from({ length: 8 }).map((_, i) => (
            <line key={i} x1={i * 160} y1="620" x2={i * 160} y2="675" stroke="#BFB5A2" strokeWidth="1.5" />
          ))}

          {/* Warm 2700K ambient overall grade */}
          <rect width="1200" height="675" fill="rgba(255, 235, 200, 0.05)" />
        </svg>
      );

    case 'living':
      return (
        <svg className="w-full h-full object-cover" viewBox="0 0 1200 675" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
          <rect width="1200" height="675" fill="#FAF8F5" />
          {/* Soft natural window lighting */}
          <polygon points="180,100 580,100 700,675 0,675" fill="rgba(255, 240, 210, 0.25)" />

          {/* Window with tension rod linen drapes */}
          <rect x="180" y="100" width="400" height="320" fill="#D3E5ED" stroke="#4A3B32" strokeWidth="2" />
          {/* Tension rod */}
          <rect x="160" y="90" width="440" height="10" rx="3" fill="#2C2724" />
          {/* Belgian linen curtain panels flanking window */}
          <path d="M 160 98 Q 170 280, 165 440 L 230 440 Q 220 280, 215 98 Z" fill="#EAE5DB" stroke="#CCC4B5" strokeWidth="1.5" />
          <path d="M 545 98 Q 540 280, 550 440 L 610 440 Q 600 280, 595 98 Z" fill="#EAE5DB" stroke="#CCC4B5" strokeWidth="1.5" />

          {/* Zero-drill Command-strip gallery wall: 3 curated minimalist linen prints */}
          <g>
            <rect x="660" y="140" width="130" height="170" fill="#FAF8F5" stroke="#4A3B32" strokeWidth="4" />
            <rect x="680" y="160" width="90" height="130" fill="#EFECE6" />
            <circle cx="725" cy="225" r="28" fill="#C69C6D" opacity="0.8" />

            <rect x="820" y="140" width="130" height="170" fill="#FAF8F5" stroke="#4A3B32" strokeWidth="4" />
            <rect x="840" y="160" width="90" height="130" fill="#EFECE6" />
            <path d="M 855 260 Q 885 180, 915 250" stroke="#6E7864" strokeWidth="3" fill="none" />

            <rect x="980" y="140" width="130" height="170" fill="#FAF8F5" stroke="#4A3B32" strokeWidth="4" />
            <rect x="1000" y="160" width="90" height="130" fill="#EFECE6" />
            <line x1="1015" y1="225" x2="1075" y2="225" stroke="#2C2724" strokeWidth="2.5" />
          </g>

          {/* Floor base */}
          <rect x="0" y="440" width="1200" height="235" fill="#C5B79F" />

          {/* OVERSIZED WASHABLE JAPANDI AREA RUG (Completely hides ugly rental carpet) */}
          <g>
            {/* Rug body */}
            <polygon points="120,445 1080,445 1160,665 40,665" fill="#EBE6DC" stroke="#D3CCC0" strokeWidth="2" />
            {/* Subtle woven texture lines */}
            {Array.from({ length: 14 }).map((_, i) => (
              <line key={i} x1={80 + i * 75} y1="455" x2={60 + i * 82} y2="655" stroke="#DDD7CB" strokeWidth="1.5" />
            ))}
            {/* Woven fringe border */}
            <line x1="40" y1="663" x2="1160" y2="663" stroke="#C8C0B2" strokeWidth="3" strokeDasharray="4,4" />
          </g>

          {/* Cream Bouclé Modern Sofa */}
          <rect x="520" y="340" width="480" height="170" rx="16" fill="#F0ECE1" stroke="#D9D2C4" strokeWidth="2" />
          <rect x="545" y="315" width="430" height="90" rx="12" fill="#F5F2EB" stroke="#DDD6C9" strokeWidth="2" />
          {/* Pillows: Sage Green and Textured Greige */}
          <rect x="555" y="345" width="65" height="65" rx="8" fill="#6E7864" transform="rotate(-6 555 345)" />
          <rect x="880" y="345" width="70" height="70" rx="8" fill="#C69C6D" transform="rotate(8 880 345)" />

          {/* Low profile pale oak coffee table */}
          <ellipse cx="680" cy="530" rx="150" ry="32" fill="#D7CCA8" stroke="#B8A77E" strokeWidth="2" />
          {/* Ceramic book & candle */}
          <rect x="650" y="505" width="45" height="20" rx="2" fill="#FAF8F5" stroke="#999" />
          <circle cx="715" cy="512" r="8" fill="#FFF3D4" />

          {/* 2700K Arched Paper Lantern Floor Lamp (Plug-in, Zero Drill) */}
          <path d="M 1080 580 L 1080 380 Q 1080 180, 960 210" stroke="#2C2724" strokeWidth="5" fill="none" />
          <ellipse cx="960" cy="240" rx="26" ry="32" fill="#FFF2D6" stroke="#C69C6D" strokeWidth="2" />
          <circle cx="960" cy="240" r="14" fill="#FFE5A3" opacity="0.8" />
        </svg>
      );

    case 'bathroom':
      return (
        <svg className="w-full h-full object-cover" viewBox="0 0 1200 675" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
          <rect width="1200" height="675" fill="#FAF8F5" />
          {/* Peel-and-stick subtle textured Japandi linen wallpaper */}
          <rect width="1200" height="440" fill="#EAE5DC" />
          {Array.from({ length: 24 }).map((_, i) => (
            <line key={i} x1={i * 50} y1="0" x2={i * 50} y2="440" stroke="#DFD9CD" strokeWidth="1" strokeDasharray="3,3" />
          ))}

          {/* Magnetic / overlay warm walnut mirror frame */}
          <rect x="350" y="100" width="500" height="320" rx="8" fill="#4A3B32" stroke="#2C2724" strokeWidth="3" />
          <rect x="370" y="120" width="460" height="280" fill="#D4E7F0" />

          {/* 2700K Warm globe bulb covers over vanity */}
          <rect x="420" y="65" width="360" height="15" fill="#2C2724" />
          <circle cx="480" cy="72" r="18" fill="#FFF2D4" stroke="#C69C6D" strokeWidth="2" />
          <circle cx="600" cy="72" r="18" fill="#FFF2D4" stroke="#C69C6D" strokeWidth="2" />
          <circle cx="720" cy="72" r="18" fill="#FFF2D4" stroke="#C69C6D" strokeWidth="2" />

          {/* Floor-to-ceiling tension plant & towel storage shelf */}
          <rect x="920" y="0" width="8" height="675" fill="#2C2724" />
          <rect x="1080" y="0" width="8" height="675" fill="#2C2724" />
          <rect x="920" y="220" width="168" height="14" rx="2" fill="#D7CCA8" stroke="#4A3B32" strokeWidth="1" />
          <rect x="920" y="340" width="168" height="14" rx="2" fill="#D7CCA8" stroke="#4A3B32" strokeWidth="1" />
          <rect x="920" y="460" width="168" height="14" rx="2" fill="#D7CCA8" stroke="#4A3B32" strokeWidth="1" />
        </svg>
      );

    case 'bedroom':
      return (
        <svg className="w-full h-full object-cover" viewBox="0 0 1200 675" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
          <rect width="1200" height="675" fill="#F7F4EE" />
          <rect x="0" y="450" width="1200" height="225" fill="#C2B59F" />
          {/* Oversized layered washable runner */}
          <polygon points="200,460 1000,460 1080,660 120,660" fill="#EAE5DB" stroke="#D5CEC2" strokeWidth="2" />
          {/* Linen upholstered bed */}
          <rect x="320" y="300" width="560" height="240" rx="8" fill="#F0ECE1" stroke="#DDD6C7" strokeWidth="2" />
          <rect x="350" y="240" width="500" height="90" rx="6" fill="#DDD6C7" />
          {/* Plug-in brass sconces on each side */}
          <circle cx="270" cy="260" r="14" fill="#FFEAB8" stroke="#C69C6D" strokeWidth="2" />
          <line x1="270" y1="274" x2="270" y2="440" stroke="#C69C6D" strokeWidth="2" />
          <circle cx="930" cy="260" r="14" fill="#FFEAB8" stroke="#C69C6D" strokeWidth="2" />
          <line x1="930" y1="274" x2="930" y2="440" stroke="#C69C6D" strokeWidth="2" />
        </svg>
      );
  }
};
