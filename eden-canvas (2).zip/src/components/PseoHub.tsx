import React, { useState } from 'react';
import { ChevronDown, ShieldCheck, Sparkles, Compass, Check, ArrowRight } from 'lucide-react';
import { PSEO_ROUTES, PseoMetadata } from '../utils/design-engine';

interface PseoHubProps {
  onSelectRouteForStudio: (route: PseoMetadata) => void;
}

export const PseoHub: React.FC<PseoHubProps> = ({ onSelectRouteForStudio }) => {
  const [selectedSlug, setSelectedSlug] = useState<string>(PSEO_ROUTES[0].slug);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const activeRoute = PSEO_ROUTES.find(r => r.slug === selectedSlug) || PSEO_ROUTES[0];

  const toggleFaq = (index: number) => {
    setOpenFaqIndex(prev => (prev === index ? null : index));
  };

  return (
    <section id="pseo-hub" className="relative w-full py-20 px-6 bg-[#F0ECE1] border-t border-[#B8B2A6]/40">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FAF8F5] border border-[#B8B2A6]/40 text-xs font-medium text-[#4A3B32] shadow-2xs mb-3">
            <Compass className="w-3.5 h-3.5 text-[#C69C6D]" />
            <span>Programmatic SEO (pSEO) Architectural Hub</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-[#2C2724]">
            Explore Renter Makeovers by Room & Technique
          </h2>
          <p className="text-sm text-[#655E56] mt-2">
            Dynamic landing routes optimized for high-intent search queries. Each page injects tailored lease-safety parameters, budgets, and verified FAQ accordions.
          </p>
        </div>

        {/* Dynamic Route Switcher Tabs */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-10">
          {PSEO_ROUTES.map(route => {
            const isSelected = route.slug === selectedSlug;
            return (
              <button
                key={route.slug}
                onClick={() => {
                  setSelectedSlug(route.slug);
                  setOpenFaqIndex(0);
                }}
                className={`px-4 py-2 rounded-xl text-xs font-mono transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-[#4A3B32] text-[#FAF8F5] shadow-xs font-semibold'
                    : 'bg-[#FAF8F5] text-[#655E56] hover:text-[#2C2724] border border-[#B8B2A6]/40'
                }`}
              >
                {route.slug}
              </button>
            );
          })}
        </div>

        {/* Dynamic Route Content Preview Container */}
        <div className="p-6 sm:p-10 rounded-3xl bg-[#FAF8F5] border border-[#B8B2A6]/40 shadow-xl max-w-4xl mx-auto">
          {/* Breadcrumb Path */}
          <div className="flex items-center gap-2 text-xs font-mono text-[#8C8275] mb-4">
            <span>eden-canvas.com</span>
            <span>/</span>
            <span>makeover</span>
            <span>/</span>
            <span className="text-[#4A3B32] font-semibold">{activeRoute.room}</span>
            <span>/</span>
            <span className="text-[#C69C6D] font-semibold">{activeRoute.style}</span>
          </div>

          {/* Dynamic H1 Title */}
          <h3 className="font-serif text-2xl sm:text-3xl md:text-4xl font-bold text-[#2C2724] leading-tight">
            {activeRoute.h1Title}
          </h3>

          <p className="text-sm sm:text-base text-[#655E56] mt-3 leading-relaxed">
            {activeRoute.subheadline}
          </p>

          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 my-8 p-4 rounded-2xl bg-[#F0ECE1] border border-[#B8B2A6]/30">
            <div>
              <span className="text-[10px] font-mono uppercase text-[#8C8275] block">
                Deposit Safety Score
              </span>
              <span className="text-lg font-bold text-emerald-800 flex items-center gap-1 mt-0.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600" /> {activeRoute.depositSafetyScore}% Guaranteed
              </span>
            </div>
            <div>
              <span className="text-[10px] font-mono uppercase text-[#8C8275] block">
                Estimated Renter Budget
              </span>
              <span className="text-lg font-bold text-[#2C2724] mt-0.5 block">
                {activeRoute.estimatedBudget}
              </span>
            </div>
            <div className="col-span-2 sm:col-span-1">
              <span className="text-[10px] font-mono uppercase text-[#8C8275] block">
                Hardware Intervention
              </span>
              <span className="text-xs font-semibold text-[#4A3B32] capitalize mt-1 block">
                {activeRoute.technique.replace(/-/g, ' ')}
              </span>
            </div>
          </div>

          {/* Interactive Lease-Safety FAQ Accordions */}
          <div className="space-y-3">
            <h4 className="font-serif text-xl font-bold text-[#2C2724] mb-3">
              Lease-Safety & Landlord Compliance FAQs
            </h4>

            {activeRoute.faqs.map((faq, idx) => {
              const isOpen = openFaqIndex === idx;
              return (
                <div
                  key={idx}
                  className="rounded-xl border border-[#B8B2A6]/40 overflow-hidden bg-white/70 transition-colors"
                >
                  <button
                    onClick={() => toggleFaq(idx)}
                    className="w-full p-4 text-left flex items-center justify-between gap-4 font-semibold text-xs sm:text-sm text-[#2C2724] cursor-pointer hover:bg-black/2"
                  >
                    <span>{faq.question}</span>
                    <ChevronDown
                      className={`w-4 h-4 text-[#8C8275] shrink-0 transition-transform ${
                        isOpen ? 'rotate-180 text-[#4A3B32]' : ''
                      }`}
                    />
                  </button>

                  {isOpen && (
                    <div className="p-4 pt-0 text-xs sm:text-sm text-[#655E56] leading-relaxed border-t border-[#B8B2A6]/20 bg-[#FAF8F5]">
                      {faq.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Call to action for this route */}
          <div className="mt-8 pt-6 border-t border-[#B8B2A6]/30 flex flex-col sm:flex-row items-center justify-between gap-4">
            <span className="text-xs text-[#8C8275]">
              Ready to restyle your {activeRoute.room} with zero deposit risk?
            </span>
            <button
              onClick={() => onSelectRouteForStudio(activeRoute)}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-[#4A3B32] hover:bg-[#382C25] text-[#FAF8F5] text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer shadow-sm transition-all"
            >
              <span>Load This Preset in Studio</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#C69C6D]" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
