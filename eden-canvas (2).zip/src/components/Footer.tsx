import React from 'react';
import { ShieldCheck, Info } from 'lucide-react';

interface FooterProps {
  onOpenPricing: () => void;
  onOpenEngine: () => void;
  onScrollToStudio: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onOpenPricing,
  onOpenEngine,
  onScrollToStudio
}) => {
  return (
    <footer className="w-full bg-[#241F1C] text-[#B8B2A6] py-16 px-6 border-t border-[#4A3B32]">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 pb-12 border-b border-[#4A3B32]/60">
          {/* Col 1: Brand & Renter Mission */}
          <div className="md:col-span-2">
            <span className="font-serif text-2xl font-bold text-[#FAF8F5] tracking-tight">
              Eden Canvas
            </span>
            <span className="block text-xs font-mono uppercase tracking-widest text-[#C69C6D] mt-0.5">
              by Wold Eden
            </span>
            <p className="text-xs sm:text-sm text-[#A8A196] mt-3 max-w-md leading-relaxed">
              The first AI interior design SaaS engineered specifically for the 46.1 million American renter households. We eliminate 100% of decorating anxieties with strict ControlNet geometry locking, zero-drill hardware, and peel-and-stick transformations.
            </p>
            <div className="mt-4 flex items-center gap-2 text-xs text-emerald-400 font-medium">
              <ShieldCheck className="w-4 h-4" />
              <span>100% Security Deposit Protection Guarantee</span>
            </div>
          </div>

          {/* Col 2: Studio Navigation */}
          <div>
            <h4 className="font-serif text-sm font-semibold text-[#FAF8F5] uppercase tracking-wider mb-3">
              Studio Platform
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={onScrollToStudio}
                  className="hover:text-[#FAF8F5] transition-colors cursor-pointer"
                >
                  Zero-Damage Studio Canvas
                </button>
              </li>
              <li>
                <a href="#presets" className="hover:text-[#FAF8F5] transition-colors">
                  90s Honey-Oak Kitchen Fix
                </a>
              </li>
              <li>
                <a href="#presets" className="hover:text-[#FAF8F5] transition-colors">
                  Rental Carpet Camouflage
                </a>
              </li>
              <li>
                <a href="#amazon-drawer" className="hover:text-[#FAF8F5] transition-colors">
                  Amazon Lease-Safe Checklist
                </a>
              </li>
              <li>
                <button
                  onClick={onOpenPricing}
                  className="hover:text-[#FAF8F5] transition-colors cursor-pointer"
                >
                  Credit Packs & Pro Vault
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Developer & Architecture */}
          <div>
            <h4 className="font-serif text-sm font-semibold text-[#FAF8F5] uppercase tracking-wider mb-3">
              Developer Architecture
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={onOpenEngine}
                  className="hover:text-[#FAF8F5] transition-colors cursor-pointer text-left"
                >
                  Netlify Serverless Function
                </button>
              </li>
              <li>
                <span className="text-[#8C8275]">ControlNet Depth (FLUX)</span>
              </li>
              <li>
                <span className="text-[#8C8275]">ZeroBounce Disposable Email API</span>
              </li>
              <li>
                <span className="text-emerald-400">Zero-Risk 500 Credit Refund</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom FTC Disclosure & Copyright */}
        <div className="pt-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 text-xs text-[#8C8275]">
          <div className="max-w-2xl text-[11px] leading-relaxed">
            <span className="text-[#B8B2A6] font-semibold flex items-center gap-1 mb-0.5">
              <Info className="w-3 h-3 text-[#C69C6D]" /> FTC Affiliate Disclosure:
            </span>
            Eden Canvas by Wold Eden is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to Amazon.com. All products recommended are independent editorial picks tested for damage-free lease compliance.
          </div>

          <div className="shrink-0 text-right text-[11px]">
            <p>© {new Date().getFullYear()} Wold Eden Inc. All rights reserved.</p>
            <p className="mt-0.5 text-[#C69C6D]">Transform Your Rental. Keep Your Deposit.</p>
          </div>
        </div>
      </div>
    </footer>
  );
};
