import React from 'react';
import { Sparkles, Shield, Key } from 'lucide-react';

interface HeaderProps {
  credits: number;
  maxCredits: number;
  isPro: boolean;
  onOpenPricing: () => void;
  onOpenEngine: () => void;
  onScrollToStudio: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  credits,
  maxCredits,
  isPro,
  onOpenPricing,
  onOpenEngine,
  onScrollToStudio
}) => {
  return (
    <header className="sticky top-0 z-50 w-full glass-luxury border-b border-[#B8B2A6]/30 px-6 py-3.5 transition-all">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark (Single text element wordmark in editorial serif) */}
        <a
          href="#"
          className="text-xl md:text-2xl font-serif font-bold tracking-tight text-[#2C2724] whitespace-nowrap shrink-0 hover:text-[#4A3B32] transition-colors"
        >
          Eden Canvas
        </a>

        {/* Zone 2: Clean single-line text links with hover underlines */}
        <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-[#655E56]">
          <button
            onClick={onScrollToStudio}
            className="hover:text-[#2C2724] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Studio Canvas
          </button>
          <a
            href="#presets"
            className="hover:text-[#2C2724] transition-colors whitespace-nowrap shrink-0"
          >
            Baseline Fixes
          </a>
          <a
            href="#amazon-drawer"
            className="hover:text-[#2C2724] transition-colors whitespace-nowrap shrink-0"
          >
            Amazon Checklist
          </a>
        </nav>

        {/* Zone 3: 1 Primary Action & Credit Status */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Credit balance display */}
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#F0ECE1] border border-[#B8B2A6]/40 text-xs font-medium text-[#4A3B32] tabular-nums shadow-xs">
            <Sparkles className="w-3.5 h-3.5 text-[#C69C6D]" />
            <span>Credits:</span>
            <span className="font-semibold text-[#2C2724]">{credits}/{maxCredits}</span>
            {isPro && (
              <span className="ml-1 text-[10px] px-1.5 py-0.2 bg-[#4A3B32] text-[#FAF8F5] rounded font-semibold uppercase">
                Pro
              </span>
            )}
          </div>

          {/* Primary CTA button */}
          <button
            onClick={onOpenPricing}
            className="px-4 py-2 text-xs font-semibold text-[#FAF8F5] bg-[#4A3B32] hover:bg-[#382C25] active:scale-98 transition-all rounded-lg whitespace-nowrap shrink-0 cursor-pointer shadow-sm flex items-center gap-1.5"
          >
            <Shield className="w-3.5 h-3.5 text-[#C69C6D]" />
            <span>{isPro ? 'Pro Vault Active' : 'Get Credits / Pro Vault'}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
