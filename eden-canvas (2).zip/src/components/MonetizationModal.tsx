import React, { useState } from 'react';
import { X, Check, Sparkles, BookOpen, Download, Shield, Zap, Lock, Unlock } from 'lucide-react';

interface MonetizationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddCredits: (amount: number, isPro?: boolean) => void;
  isPro: boolean;
}

export const MonetizationModal: React.FC<MonetizationModalProps> = ({
  isOpen,
  onClose,
  onAddCredits,
  isPro
}) => {
  const [selectedPack, setSelectedPack] = useState<'refresh' | 'overhaul' | 'vip'>('overhaul');
  const [simulatingCheckout, setSimulatingCheckout] = useState<boolean>(false);
  const [purchasedSuccess, setPurchasedSuccess] = useState<string | null>(null);

  if (!isOpen) return null;

  const handlePurchase = (pack: 'refresh' | 'overhaul' | 'vip') => {
    setSimulatingCheckout(true);

    setTimeout(() => {
      setSimulatingCheckout(false);
      if (pack === 'refresh') {
        onAddCredits(25, false);
        setPurchasedSuccess('25 Credits added to your studio wallet!');
      } else if (pack === 'overhaul') {
        onAddCredits(75, false);
        setPurchasedSuccess('75 Credits added to your studio wallet!');
      } else {
        onAddCredits(150, true);
        setPurchasedSuccess('VIP Studio Pass Active! 150 Credits & Digital Vault unlocked!');
      }

      setTimeout(() => {
        setPurchasedSuccess(null);
        onClose();
      }, 1500);
    }, 700);
  };

  const handleDownloadVaultItem = (itemTitle: string) => {
    const content = `WOLD EDEN DIGITAL VAULT
=======================================
Asset: ${itemTitle}
License: VIP Studio Member
Status: Deposit-Safe Certified

Contents:
- Full 60-page lease-safe diagnostic rubric
- Landlord-approved contact paper removal guide
- Temperature & humidity testing thresholds for peel-and-stick adhesives
- FTC-compliant shopping recommendations with product ASINs

(c) Wold Eden Studio. All rights reserved.`;

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${itemTitle.toLowerCase().replace(/\s+/g, '-')}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-3xl p-6 sm:p-8 glass-luxury border border-[#B8B2A6]/40 shadow-2xl">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full hover:bg-black/5 text-[#8C8275] hover:text-[#2C2724] transition-colors cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="text-center max-w-xl mx-auto mb-8">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FAF8F5] border border-[#B8B2A6]/40 text-xs font-semibold text-[#4A3B32] mb-3">
            <Sparkles className="w-3.5 h-3.5 text-[#C69C6D]" />
            <span>Zero Subscription Fatigue · One-Time Credit Packs</span>
          </div>
          <h3 className="font-serif text-3xl font-bold text-[#2C2724]">
            Invest in Your Space. Keep Your Cash.
          </h3>
          <p className="text-sm text-[#655E56] mt-2">
            No recurring monthly charges. Purchase only what you need for your move-in or weekend project.
          </p>
        </div>

        {/* Success Alert */}
        {purchasedSuccess && (
          <div className="mb-6 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm font-semibold flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-600" />
            <span>{purchasedSuccess}</span>
          </div>
        )}

        {/* 3 Pricing Tier Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {/* Tier 1: Room Refresh Pack */}
          <div
            onClick={() => setSelectedPack('refresh')}
            className={`p-6 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
              selectedPack === 'refresh'
                ? 'border-[#4A3B32] bg-[#F0ECE1] shadow-md'
                : 'border-[#B8B2A6]/40 bg-[#FAF8F5] hover:border-[#B8B2A6]'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-[#8C8275] uppercase tracking-wider">
                  Weekend Project
                </span>
              </div>
              <h4 className="font-serif text-xl font-bold text-[#2C2724]">Room Refresh Pack</h4>
              <p className="text-xs text-[#655E56] mt-1">Perfect for transforming a single kitchen or bedroom.</p>
              
              <div className="my-5">
                <span className="text-3xl font-bold font-serif text-[#2C2724] tabular-nums">$4.99</span>
                <span className="text-xs text-[#8C8275] ml-1">one-time</span>
              </div>

              <ul className="space-y-2 text-xs text-[#4A3B32] border-t border-[#B8B2A6]/30 pt-4">
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-[#6E7864]" /> 25 Studio Generation Credits
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-[#6E7864]" /> ControlNet Depth Geometry Lock
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-[#6E7864]" /> Amazon Shoppable Checklist
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-[#6E7864]" /> Zero-Risk 500 Error Refund
                </li>
              </ul>
            </div>

            <button
              onClick={e => {
                e.stopPropagation();
                handlePurchase('refresh');
              }}
              disabled={simulatingCheckout}
              className="mt-6 w-full py-2.5 rounded-xl bg-[#FAF8F5] hover:bg-[#EAE5D9] text-[#4A3B32] font-semibold text-xs border border-[#B8B2A6] transition-all cursor-pointer"
            >
              Get 25 Credits
            </button>
          </div>

          {/* Tier 2: Apartment Overhaul Pack (Most Popular) */}
          <div
            onClick={() => setSelectedPack('overhaul')}
            className={`relative p-6 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
              selectedPack === 'overhaul'
                ? 'border-[#4A3B32] bg-[#FAF8F5] shadow-xl ring-2 ring-[#4A3B32]'
                : 'border-[#B8B2A6]/40 bg-[#FAF8F5] hover:border-[#B8B2A6]'
            }`}
          >
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-[#4A3B32] text-[#FAF8F5] text-[10px] font-bold uppercase tracking-wider">
              Most Popular
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-[#C69C6D] uppercase tracking-wider">
                  New Move-Ins
                </span>
              </div>
              <h4 className="font-serif text-xl font-bold text-[#2C2724]">Apartment Overhaul</h4>
              <p className="text-xs text-[#655E56] mt-1">Enough credits for living room, kitchen, bath & bed.</p>
              
              <div className="my-5">
                <span className="text-3xl font-bold font-serif text-[#2C2724] tabular-nums">$9.99</span>
                <span className="text-xs text-[#8C8275] ml-1">one-time</span>
              </div>

              <ul className="space-y-2 text-xs text-[#4A3B32] border-t border-[#B8B2A6]/30 pt-4">
                <li className="flex items-center gap-2 font-semibold">
                  <Check className="w-3.5 h-3.5 text-[#6E7864]" /> 75 Studio Generation Credits
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-[#6E7864]" /> Full Apartment Multi-Room Presets
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-[#6E7864]" /> High-Res Spec Sheet Export
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-[#6E7864]" /> Priority GPU Pipeline Queue
                </li>
              </ul>
            </div>

            <button
              onClick={e => {
                e.stopPropagation();
                handlePurchase('overhaul');
              }}
              disabled={simulatingCheckout}
              className="mt-6 w-full py-2.5 rounded-xl bg-[#4A3B32] hover:bg-[#382C25] text-[#FAF8F5] font-semibold text-xs transition-all cursor-pointer shadow-sm"
            >
              Get 75 Credits
            </button>
          </div>

          {/* Tier 3: VIP Studio Pass + Wold Eden Digital Vault */}
          <div
            onClick={() => setSelectedPack('vip')}
            className={`p-6 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
              selectedPack === 'vip'
                ? 'border-[#C69C6D] bg-[#F5F2EB] shadow-md'
                : 'border-[#B8B2A6]/40 bg-[#FAF8F5] hover:border-[#B8B2A6]'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-[#C69C6D] uppercase tracking-wider flex items-center gap-1">
                  <Zap className="w-3 h-3 text-[#C69C6D]" /> VIP Pass
                </span>
                {isPro && (
                  <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold uppercase">
                    Active
                  </span>
                )}
              </div>
              <h4 className="font-serif text-xl font-bold text-[#2C2724]">VIP Studio Pass</h4>
              <p className="text-xs text-[#655E56] mt-1">150 credits + instant access to the Wold Eden Digital Vault.</p>
              
              <div className="my-5">
                <span className="text-3xl font-bold font-serif text-[#2C2724] tabular-nums">$14.99</span>
                <span className="text-xs text-[#8C8275] ml-1">one-time</span>
              </div>

              <ul className="space-y-2 text-xs text-[#4A3B32] border-t border-[#B8B2A6]/30 pt-4">
                <li className="flex items-center gap-2 font-semibold">
                  <Check className="w-3.5 h-3.5 text-[#C69C6D]" /> 150 Generation Credits
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-[#C69C6D]" /> Watermark Removal
                </li>
                <li className="flex items-center gap-2 font-semibold text-[#4A3B32]">
                  <BookOpen className="w-3.5 h-3.5 text-[#C69C6D]" /> Full Wold Eden Digital Vault
                </li>
              </ul>
            </div>

            <button
              onClick={e => {
                e.stopPropagation();
                handlePurchase('vip');
              }}
              disabled={simulatingCheckout}
              className="mt-6 w-full py-2.5 rounded-xl bg-[#C69C6D] hover:bg-[#B88B5A] text-[#2C2724] font-semibold text-xs transition-all cursor-pointer shadow-sm"
            >
              {isPro ? 'Top Up 150 Credits' : 'Unlock VIP + Digital Vault'}
            </button>
          </div>
        </div>

        {/* Wold Eden Digital Vault Showcase */}
        <div className="p-6 rounded-2xl bg-[#FAF8F5] border border-[#B8B2A6]/50">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 pb-4 border-b border-[#B8B2A6]/30">
            <div>
              <div className="flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-[#C69C6D]" />
                <h4 className="font-serif text-lg font-bold text-[#2C2724]">
                  The Wold Eden Digital Vault
                </h4>
              </div>
              <p className="text-xs text-[#655E56] mt-0.5">
                Included 100% free with the VIP Studio Pass ($97 value).
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs text-[#8C8275]">
                {isPro ? (
                  <span className="text-emerald-700 font-semibold flex items-center gap-1">
                    <Unlock className="w-3.5 h-3.5" /> All Assets Unlocked
                  </span>
                ) : (
                  <span className="text-[#8C8275] flex items-center gap-1">
                    <Lock className="w-3.5 h-3.5" /> Unlocks with VIP Pass
                  </span>
                )}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-3.5 rounded-xl bg-[#F0ECE1] border border-[#B8B2A6]/30 flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-mono text-[#8C8275] uppercase">Item 01</span>
                <h5 className="text-xs font-bold text-[#2C2724] mt-1">60-Page Room Diagnostic Kit</h5>
                <p className="text-[11px] text-[#655E56] mt-1">
                  How to test peel-and-stick adhesives on rental surfaces without paint damage.
                </p>
              </div>
              <button
                onClick={() => handleDownloadVaultItem('60-Page Room Diagnostic Kit')}
                disabled={!isPro}
                className="mt-3 py-1.5 px-3 rounded-lg bg-white hover:bg-[#FAF8F5] disabled:opacity-40 text-[#4A3B32] text-xs font-medium border border-[#B8B2A6]/40 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <Download className="w-3 h-3" />
                <span>{isPro ? 'Download PDF' : 'Locked (VIP)'}</span>
              </button>
            </div>

            <div className="p-3.5 rounded-xl bg-[#F0ECE1] border border-[#B8B2A6]/30 flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-mono text-[#8C8275] uppercase">Item 02</span>
                <h5 className="text-xs font-bold text-[#2C2724]">The Pinterest Reality Gap</h5>
                <p className="text-[11px] text-[#655E56] mt-1">
                  Translating luxury interior mood boards into zero-drill rental execution.
                </p>
              </div>
              <button
                onClick={() => handleDownloadVaultItem('The Pinterest Reality Gap Workbook')}
                disabled={!isPro}
                className="mt-3 py-1.5 px-3 rounded-lg bg-white hover:bg-[#FAF8F5] disabled:opacity-40 text-[#4A3B32] text-xs font-medium border border-[#B8B2A6]/40 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <Download className="w-3 h-3" />
                <span>{isPro ? 'Download PDF' : 'Locked (VIP)'}</span>
              </button>
            </div>

            <div className="p-3.5 rounded-xl bg-[#F0ECE1] border border-[#B8B2A6]/30 flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-mono text-[#8C8275] uppercase">Item 03</span>
                <h5 className="text-xs font-bold text-[#2C2724]">Room to Breathe Planner</h5>
                <p className="text-[11px] text-[#655E56] mt-1">
                  Space-planning template for awkward floor plans, radiator gaps, and rental corners.
                </p>
              </div>
              <button
                onClick={() => handleDownloadVaultItem('Room to Breathe Planner')}
                disabled={!isPro}
                className="mt-3 py-1.5 px-3 rounded-lg bg-white hover:bg-[#FAF8F5] disabled:opacity-40 text-[#4A3B32] text-xs font-medium border border-[#B8B2A6]/40 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <Download className="w-3 h-3" />
                <span>{isPro ? 'Download PDF' : 'Locked (VIP)'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
