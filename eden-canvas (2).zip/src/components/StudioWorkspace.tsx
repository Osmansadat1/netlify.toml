import React, { useState, useRef } from 'react';
import {
  Upload,
  Sparkles,
  CheckCircle2,
  Lock,
  Download,
  ShoppingBag,
  ExternalLink,
  RefreshCw,
  Sliders,
  Send,
  AlertTriangle,
  Info,
  DollarSign,
  ShieldCheck
} from 'lucide-react';
import {
  STYLES,
  RENTER_PRESETS,
  RENTER_SHOPPABLE_CATALOG,
  buildAmazonAffiliateUrl,
  compileDesignPrompt
} from '../utils/design-engine';
import { RoomCanvasVisualizer, RoomSceneId } from './RoomCanvasVisualizer';

interface StudioWorkspaceProps {
  credits: number;
  isEmailVerified: boolean;
  onTriggerGenerate: (config: {
    roomType: string;
    styleId: string;
    activePresets: string[];
    userPrompt: string;
  }) => void;
  onOpenPricing: () => void;
  onSimulateRefund: () => void;
  isGenerating: boolean;
  isBlurred: boolean;
  lastGeneratedTime: number | null;
}

export const StudioWorkspace: React.FC<StudioWorkspaceProps> = ({
  credits,
  isEmailVerified,
  onTriggerGenerate,
  onOpenPricing,
  onSimulateRefund,
  isGenerating,
  isBlurred,
  lastGeneratedTime
}) => {
  // Studio selections
  const [selectedRoom, setSelectedRoom] = useState<RoomSceneId>('kitchen');
  const [selectedStyle, setSelectedStyle] = useState<string>('japandi');
  const [activePresets, setActivePresets] = useState<string[]>(['honey-oak-kitchen', 'zero-drill-lighting']);
  const [chatPrompt, setChatPrompt] = useState<string>('');
  const [chatHistory, setChatHistory] = useState<Array<{ sender: 'user' | 'assistant'; text: string }>>([
    {
      sender: 'assistant',
      text: 'Eden Renter Studio initialized. Walls and window frames are locked with ControlNet Depth. All suggestions are 100% peel-and-stick and damage-free.'
    }
  ]);
  const [uploadedImagePreview, setUploadedImagePreview] = useState<string | null>(null);
  const [showAmazonDrawer, setShowAmazonDrawer] = useState<boolean>(true);
  const [budgetFilter, setBudgetFilter] = useState<'all' | 'under50' | 'under150' | 'full'>('all');
  const [isCopiedSpec, setIsCopiedSpec] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Toggle presets
  const togglePreset = (presetId: string) => {
    setActivePresets(prev =>
      prev.includes(presetId) ? prev.filter(id => id !== presetId) : [...prev, presetId]
    );
  };

  // Handle custom file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setUploadedImagePreview(reader.result as string);
        setChatHistory(prev => [
          ...prev,
          {
            sender: 'assistant',
            text: `Analyzed uploaded room "${file.name}". Detected structural boundaries and ceiling height. ControlNet Geometry Lock engaged.`
          }
        ]);
      };
      reader.readAsDataURL(file);
    }
  };

  // Preset room switcher
  const handleSelectPresetRoom = (roomId: RoomSceneId) => {
    setSelectedRoom(roomId);
    setUploadedImagePreview(null);
    if (roomId === 'kitchen') {
      setActivePresets(['honey-oak-kitchen', 'zero-drill-lighting']);
    } else if (roomId === 'living') {
      setActivePresets(['hide-carpet', 'zero-drill-lighting']);
    } else if (roomId === 'bathroom') {
      setActivePresets(['rental-bathroom', 'zero-drill-lighting']);
    } else {
      setActivePresets(['zero-drill-lighting']);
    }
  };

  // Handle companion chat submit
  const handleChatSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatPrompt.trim()) return;

    const userText = chatPrompt.trim();
    setChatPrompt('');
    setChatHistory(prev => [
      ...prev,
      { sender: 'user', text: userText },
      {
        sender: 'assistant',
        text: `Understood: "${userText}". Injected lease-safe constraints into the active prompt pipeline.`
      }
    ]);
  };

  // Handle Generate Makeover action
  const handleGenerateClick = () => {
    if (credits <= 0) {
      onOpenPricing();
      return;
    }

    onTriggerGenerate({
      roomType: selectedRoom,
      styleId: selectedStyle,
      activePresets,
      userPrompt: chatHistory.filter(m => m.sender === 'user').slice(-1)[0]?.text || ''
    });
  };

  // Filter shoppable items by budget
  const filteredProducts = RENTER_SHOPPABLE_CATALOG.filter(product => {
    if (budgetFilter === 'under50') return product.price <= 50;
    if (budgetFilter === 'under150') return product.price <= 150;
    return true;
  });

  // Download Lease-Safe Spec Sheet
  const handleDownloadSpecSheet = () => {
    const compiled = compileDesignPrompt({
      roomType: selectedRoom,
      styleId: selectedStyle,
      activePresetIds: activePresets,
      userPrompt: chatHistory.filter(m => m.sender === 'user').slice(-1)[0]?.text
    });

    const specText = `EDEN CANVAS - RENTER SPECIFICATION SHEET
=============================================
Room Type: ${selectedRoom.toUpperCase()}
Style: ${STYLES[selectedStyle]?.name}
Security Deposit Safety: 100% Guaranteed

ACTIVE RENTER INTERVENTIONS:
${activePresets.map(id => `• ${RENTER_PRESETS[id]?.title}: ${RENTER_PRESETS[id]?.shortDesc}`).join('\n')}

LEASE-SAFE HARDWARE CONSTRAINTS:
${compiled.positivePrompt}

PROHIBITED STRUCTURAL ACTIONS:
${compiled.negativePrompt}

RECOMMENDED SHOPPABLE HARDWARE:
${filteredProducts.map(p => `• ${p.title} (${p.priceFormatted}) - ${p.leaseSafeBadge}\n  Affiliate Link: ${buildAmazonAffiliateUrl(p.amazonAsin)}`).join('\n\n')}

DISCLOSURE:
As an Amazon Associate, Wold Eden earns from qualifying purchases.
=============================================`;

    const blob = new Blob([specText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `eden-canvas-${selectedRoom}-${selectedStyle}-spec-sheet.txt`;
    a.click();
    URL.revokeObjectURL(url);
    setIsCopiedSpec(true);
    setTimeout(() => setIsCopiedSpec(false), 3000);
  };

  return (
    <section id="studio" className="relative w-full py-16 px-6 bg-[#FAF8F5] border-t border-[#B8B2A6]/30">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-10 pb-6 border-b border-[#B8B2A6]/30">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono tracking-widest text-[#8C8275] uppercase">
              <span>Wold Eden</span>
              <span>/</span>
              <span className="text-[#4A3B32] font-semibold">Studio Workspace</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-serif font-bold text-[#2C2724] mt-1">
              Zero-Damage Restyling Canvas
            </h2>
            <p className="text-sm text-[#655E56] mt-1.5 max-w-xl">
              Lock existing dimensions with ControlNet. Apply peel-and-stick materials, ambient lighting, and freestanding furniture without risking a cent of your deposit.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleDownloadSpecSheet}
              className="px-4 py-2 text-xs font-semibold text-[#4A3B32] bg-[#FAF8F5] hover:bg-[#F0ECE1] border border-[#B8B2A6]/50 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer shadow-2xs"
            >
              <Download className="w-3.5 h-3.5 text-[#C69C6D]" />
              <span>{isCopiedSpec ? 'Spec Sheet Downloaded!' : 'Export Lease-Safe Spec Sheet'}</span>
            </button>
          </div>
        </div>

        {/* Split-Screen 2-Column Workspace Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* LEFT COLUMN (Control Deck & Amazon Drawer) - 5 Cols */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            {/* 1. Photo Upload & Baseline Selection */}
            <div className="p-5 rounded-2xl bg-[#FAF8F5] border border-[#B8B2A6]/40 shadow-xs">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold tracking-wide text-[#2C2724] uppercase">
                  1. Baseline Apartment Photo
                </span>
                <span className="text-[11px] text-[#8C8275]">Upload or choose preset</span>
              </div>

              {/* Preset baseline buttons */}
              <div className="grid grid-cols-4 gap-2 mb-3">
                {(['kitchen', 'living', 'bathroom', 'bedroom'] as RoomSceneId[]).map(roomId => (
                  <button
                    key={roomId}
                    onClick={() => handleSelectPresetRoom(roomId)}
                    className={`px-2 py-1.5 rounded-lg text-xs font-medium capitalize text-center transition-all cursor-pointer ${
                      selectedRoom === roomId && !uploadedImagePreview
                        ? 'bg-[#4A3B32] text-[#FAF8F5] shadow-xs'
                        : 'bg-[#F0ECE1] text-[#655E56] hover:bg-[#EAE5D9]'
                    }`}
                  >
                    {roomId}
                  </button>
                ))}
              </div>

              {/* Upload Zone */}
              <div
                onClick={() => fileInputRef.current?.click()}
                className="relative border-2 border-dashed border-[#B8B2A6]/60 hover:border-[#4A3B32] rounded-xl p-4 text-center cursor-pointer transition-colors bg-[#F5F2EB]/50 group"
              >
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  accept="image/*"
                  className="hidden"
                />
                {uploadedImagePreview ? (
                  <div className="flex items-center justify-center gap-3">
                    <img
                      src={uploadedImagePreview}
                      alt="Uploaded room baseline"
                      className="w-14 h-14 object-cover rounded-lg border border-[#B8B2A6]"
                    />
                    <div className="text-left">
                      <p className="text-xs font-semibold text-[#2C2724]">Custom Room Photo Active</p>
                      <p className="text-[11px] text-[#6E7864] flex items-center gap-1 mt-0.5">
                        <CheckCircle2 className="w-3 h-3" /> Geometry Lock Ready
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col items-center">
                    <Upload className="w-5 h-5 text-[#8C8275] group-hover:text-[#4A3B32] transition-colors mb-1.5" />
                    <p className="text-xs font-medium text-[#2C2724]">
                      Drop your rental photo or <span className="text-[#C69C6D] underline">browse</span>
                    </p>
                    <p className="text-[10px] text-[#8C8275] mt-0.5">
                      JPG, PNG, WebP up to 15MB · Auto-analyzes lighting & walls
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* 2. Aesthetic Style Selector (Visual Segmented Buttons) */}
            <div className="p-5 rounded-2xl bg-[#FAF8F5] border border-[#B8B2A6]/40 shadow-xs">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold tracking-wide text-[#2C2724] uppercase">
                  2. Aesthetic Style Direction
                </span>
                <span className="text-[11px] text-[#8C8275]">Quiet Luxury Palette</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {Object.values(STYLES).map(style => (
                  <button
                    key={style.id}
                    onClick={() => setSelectedStyle(style.id)}
                    className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                      selectedStyle === style.id
                        ? 'border-[#4A3B32] bg-[#F0ECE1] shadow-xs'
                        : 'border-[#B8B2A6]/40 hover:border-[#B8B2A6] bg-[#FAF8F5]'
                    }`}
                  >
                    <div>
                      <p className="text-xs font-semibold text-[#2C2724]">{style.name}</p>
                      <p className="text-[10px] text-[#655E56] line-clamp-1 mt-0.5">{style.tagline}</p>
                    </div>
                    {/* Palette swatches */}
                    <div className="flex items-center gap-1 mt-2">
                      {style.palette.map((color, idx) => (
                        <span
                          key={idx}
                          className="w-3 h-3 rounded-full border border-black/10"
                          style={{ backgroundColor: color }}
                        />
                      ))}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* 3. "Ugly Baseline" Renter Fix Presets (One-Click Toggles) */}
            <div id="presets" className="p-5 rounded-2xl bg-[#FAF8F5] border border-[#B8B2A6]/40 shadow-xs">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold tracking-wide text-[#2C2724] uppercase">
                  3. Ugly Baseline Fixes
                </span>
                <span className="text-[11px] text-[#6E7864] font-medium">100% Deposit Safe</span>
              </div>

              <div className="flex flex-col gap-2.5">
                {Object.values(RENTER_PRESETS).map(preset => {
                  const isActive = activePresets.includes(preset.id);
                  return (
                    <div
                      key={preset.id}
                      onClick={() => togglePreset(preset.id)}
                      className={`p-3 rounded-xl border transition-all cursor-pointer flex items-start justify-between gap-3 ${
                        isActive
                          ? 'border-[#6E7864] bg-[#6E7864]/5 shadow-2xs'
                          : 'border-[#B8B2A6]/40 hover:border-[#B8B2A6] bg-transparent'
                      }`}
                    >
                      <div className="flex items-start gap-2.5">
                        <div
                          className={`mt-0.5 w-4 h-4 rounded border flex items-center justify-center transition-colors ${
                            isActive
                              ? 'bg-[#6E7864] border-[#6E7864] text-white'
                              : 'border-[#B8B2A6] bg-white'
                          }`}
                        >
                          {isActive && <CheckCircle2 className="w-3.5 h-3.5" />}
                        </div>
                        <div>
                          <p className="text-xs font-semibold text-[#2C2724]">{preset.title}</p>
                          <p className="text-[11px] text-[#655E56] mt-0.5">{preset.shortDesc}</p>
                          <span className="text-[10px] text-[#8C8275] font-mono mt-1 inline-block">
                            Estimated Savings: {preset.typicalSavings}
                          </span>
                        </div>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 font-semibold border border-emerald-200 shrink-0">
                        0 Damage
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* 4. Companion Renter AI Chat (Fine-Tuning Mini Bar) */}
            <div className="p-4 rounded-2xl bg-[#FAF8F5] border border-[#B8B2A6]/40 shadow-xs">
              <span className="text-xs font-bold tracking-wide text-[#2C2724] uppercase block mb-2">
                4. Companion Renter AI
              </span>
              
              {/* Mini chat display */}
              <div className="max-h-28 overflow-y-auto space-y-2 mb-3 pr-1 text-xs">
                {chatHistory.slice(-2).map((msg, idx) => (
                  <div
                    key={idx}
                    className={`p-2.5 rounded-lg leading-relaxed ${
                      msg.sender === 'user'
                        ? 'bg-[#4A3B32] text-[#FAF8F5] ml-4'
                        : 'bg-[#F0ECE1] text-[#4A3B32] mr-4'
                    }`}
                  >
                    <p className="font-semibold text-[10px] uppercase tracking-wider mb-0.5 opacity-80">
                      {msg.sender === 'user' ? 'You' : 'Eden Renter AI'}
                    </p>
                    <p>{msg.text}</p>
                  </div>
                ))}
              </div>

              {/* Chat input form */}
              <form onSubmit={handleChatSubmit} className="flex items-center gap-2">
                <input
                  type="text"
                  value={chatPrompt}
                  onChange={e => setChatPrompt(e.target.value)}
                  placeholder="e.g. Swap beige rug for olive green, add brass sconces..."
                  className="flex-1 px-3 py-2 text-xs rounded-xl border border-[#B8B2A6]/60 bg-white focus:outline-none focus:ring-1 focus:ring-[#4A3B32] text-[#2C2724]"
                />
                <button
                  type="submit"
                  disabled={!chatPrompt.trim()}
                  className="p-2 rounded-xl bg-[#4A3B32] hover:bg-[#382C25] disabled:opacity-40 text-white transition-all cursor-pointer shrink-0"
                  title="Send modification instruction"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </form>
            </div>

            {/* 5. Primary Generate Makeover Button */}
            <div className="flex flex-col gap-2">
              <button
                onClick={handleGenerateClick}
                disabled={isGenerating}
                className="w-full py-4 rounded-xl bg-[#4A3B32] hover:bg-[#382C25] active:scale-98 text-[#FAF8F5] font-semibold text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-75"
              >
                <Sparkles className="w-4 h-4 text-[#C69C6D]" />
                <span>
                  {isGenerating ? 'Synthesizing Lease-Safe Transformation...' : 'Generate Makeover (1 Credit)'}
                </span>
              </button>
              
              <div className="flex items-center justify-between text-[11px] text-[#8C8275] px-1">
                <span>Available Credits: {credits}</span>
                <button
                  onClick={onOpenPricing}
                  className="text-[#4A3B32] font-semibold hover:underline cursor-pointer"
                >
                  Need more credits?
                </button>
              </div>
            </div>

            {/* 6. FTC-Compliant Amazon Shoppable Drawer */}
            <div id="amazon-drawer" className="p-5 rounded-2xl bg-[#FAF8F5] border border-[#B8B2A6]/40 shadow-xs">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <ShoppingBag className="w-4 h-4 text-[#4A3B32]" />
                  <span className="text-xs font-bold tracking-wide text-[#2C2724] uppercase">
                    Amazon Shoppable Checklist
                  </span>
                </div>
                <button
                  onClick={() => setShowAmazonDrawer(!showAmazonDrawer)}
                  className="text-xs font-medium text-[#4A3B32] hover:underline cursor-pointer"
                >
                  {showAmazonDrawer ? 'Collapse' : 'Expand'}
                </button>
              </div>

              {showAmazonDrawer && (
                <>
                  {/* Budget Filter Segmented Control */}
                  <div className="flex items-center gap-1 p-1 bg-[#F0ECE1] rounded-lg mb-3">
                    <button
                      onClick={() => setBudgetFilter('all')}
                      className={`flex-1 py-1 text-[11px] font-medium rounded-md transition-all cursor-pointer ${
                        budgetFilter === 'all'
                          ? 'bg-white text-[#2C2724] shadow-xs'
                          : 'text-[#655E56] hover:text-[#2C2724]'
                      }`}
                    >
                      All
                    </button>
                    <button
                      onClick={() => setBudgetFilter('under50')}
                      className={`flex-1 py-1 text-[11px] font-medium rounded-md transition-all cursor-pointer ${
                        budgetFilter === 'under50'
                          ? 'bg-white text-[#2C2724] shadow-xs'
                          : 'text-[#655E56] hover:text-[#2C2724]'
                      }`}
                    >
                      &lt; $50
                    </button>
                    <button
                      onClick={() => setBudgetFilter('under150')}
                      className={`flex-1 py-1 text-[11px] font-medium rounded-md transition-all cursor-pointer ${
                        budgetFilter === 'under150'
                          ? 'bg-white text-[#2C2724] shadow-xs'
                          : 'text-[#655E56] hover:text-[#2C2724]'
                      }`}
                    >
                      &lt; $150
                    </button>
                  </div>

                  {/* Product Cards List */}
                  <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
                    {filteredProducts.map(product => (
                      <div
                        key={product.id}
                        className="p-3 rounded-xl border border-[#B8B2A6]/40 bg-[#FAF8F5] flex flex-col justify-between gap-2.5"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded bg-[#6E7864]/15 text-[#4F5647]">
                                {product.leaseSafeBadge}
                              </span>
                              <span className="text-xs font-bold text-[#2C2724] tabular-nums">
                                {product.priceFormatted}
                              </span>
                            </div>
                            <h4 className="text-xs font-semibold text-[#2C2724] mt-1 line-clamp-2">
                              {product.title}
                            </h4>
                            <p className="text-[11px] text-[#655E56] mt-0.5">
                              {product.rentalFeature}
                            </p>
                          </div>
                        </div>

                        {/* Bold Shop on Amazon button with affiliate tag */}
                        <a
                          href={buildAmazonAffiliateUrl(product.amazonAsin)}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="w-full py-2 px-3 rounded-lg bg-[#FF9900] hover:bg-[#E68A00] text-[#111] font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors shadow-2xs"
                        >
                          <span>Shop on Amazon</span>
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      </div>
                    ))}
                  </div>

                  {/* FTC Affiliate Disclosure (Mandatory) */}
                  <div className="mt-3 pt-3 border-t border-[#B8B2A6]/30 text-[10px] text-[#8C8275] leading-relaxed">
                    <p className="flex items-center gap-1 font-semibold text-[#655E56] mb-0.5">
                      <Info className="w-3 h-3 text-[#C69C6D]" /> FTC Affiliate Disclosure
                    </p>
                    <p>
                      As an Amazon Associate, Wold Eden earns from qualifying purchases made through links on this page at zero additional cost to you. All items are rigorously screened for damage-free lease compliance.
                    </p>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* RIGHT COLUMN (The Interactive Visualizer Canvas) - 7 Cols */}
          <div className="lg:col-span-7 flex flex-col gap-4">
            {/* Visualizer Canvas Container */}
            <div className="relative">
              <RoomCanvasVisualizer
                sceneId={selectedRoom}
                styleName={STYLES[selectedStyle]?.name}
                isGenerating={isGenerating}
                isBlurred={isBlurred}
                autoGlideDefault={false}
                showDepthMapLock={true}
              />
            </div>

            {/* Visualizer Controls & Guarantee Bar */}
            <div className="p-4 rounded-2xl bg-[#FAF8F5] border border-[#B8B2A6]/40 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-700 shrink-0">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-[#2C2724]">Zero-Risk Credit Guarantee</h4>
                  <p className="text-[11px] text-[#655E56]">
                    Failed HTTP 500 AI generations automatically restore your spent credit instantly.
                  </p>
                </div>
              </div>

              {/* Demo test button to prove guarantee */}
              <button
                onClick={onSimulateRefund}
                className="px-3 py-1.5 rounded-lg border border-[#B8B2A6]/50 bg-white hover:bg-[#F0ECE1] text-[11px] font-medium text-[#4A3B32] transition-colors cursor-pointer shrink-0 flex items-center gap-1"
                title="Simulate an HTTP 500 error and verify automatic credit restoration"
              >
                <RefreshCw className="w-3 h-3 text-[#C69C6D]" />
                <span>Test 500 Refund Trigger</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
