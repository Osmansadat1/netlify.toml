import React, { useState, useEffect } from 'react';
import { Sparkles, ShieldCheck, Mail, ArrowRight, AlertCircle, CheckCircle, Lock } from 'lucide-react';
import { validateEmailWithZeroBounce } from '../utils/design-engine';

interface DeferredGateModalProps {
  isOpen: boolean;
  progressStep: number; // 0 to 4
  progressPercent: number; // 0 to 99
  onEmailVerified: (email: string) => void;
  onClose: () => void;
}

const STEPS = [
  'Extracting 3D Depth Map...',
  'Locking Walls & Windows (ControlNet)...',
  'Applying Peel-and-Stick Textures...',
  'Harmonizing 2700K Ambient Lighting...'
];

export const DeferredGateModal: React.FC<DeferredGateModalProps> = ({
  isOpen,
  progressStep,
  progressPercent,
  onEmailVerified,
  onClose
}) => {
  const [emailInput, setEmailInput] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [isValidating, setIsValidating] = useState<boolean>(false);
  const [isSuccess, setIsSuccess] = useState<boolean>(false);

  // Reset state when opening
  useEffect(() => {
    if (isOpen) {
      setEmailInput('');
      setErrorMessage('');
      setIsSuccess(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setIsValidating(true);

    // Simulate ZeroBounce validation latency
    setTimeout(() => {
      const validation = validateEmailWithZeroBounce(emailInput);
      setIsValidating(false);

      if (!validation.valid) {
        setErrorMessage(validation.message || 'Invalid email address.');
        return;
      }

      // Valid email
      setIsSuccess(true);
      setTimeout(() => {
        onEmailVerified(emailInput);
      }, 700);
    }, 600);
  };

  const isPausedAt99 = progressPercent >= 99;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-lg rounded-3xl p-8 glass-luxury border border-[#C69C6D]/40 shadow-2xl overflow-hidden preserve-3d">
        {/* Ambient warm glow inside modal */}
        <div className="absolute -top-20 -right-20 w-60 h-60 bg-[#C69C6D]/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-20 -left-20 w-60 h-60 bg-[#6E7864]/20 rounded-full blur-3xl pointer-events-none" />

        {/* State A: Stepper Progress Screen (While synthesizing) */}
        {!isPausedAt99 && (
          <div className="flex flex-col items-center text-center">
            <div className="relative w-20 h-20 mb-6">
              <div className="absolute inset-0 rounded-full border-4 border-[#C69C6D]/20" />
              <div
                className="absolute inset-0 rounded-full border-4 border-[#C69C6D] border-t-transparent animate-spin"
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <Sparkles className="w-8 h-8 text-[#4A3B32]" />
              </div>
            </div>

            <span className="text-xs font-mono uppercase tracking-widest text-[#8C8275] mb-1">
              Neural Synthesis Engine
            </span>
            <h3 className="font-serif text-2xl font-bold text-[#2C2724]">
              {STEPS[Math.min(progressStep, STEPS.length - 1)]}
            </h3>

            {/* Progress Bar */}
            <div className="w-full bg-[#EAE5D9] h-2.5 rounded-full overflow-hidden mt-6 mb-2">
              <div
                className="bg-[#4A3B32] h-full transition-all duration-300 rounded-full"
                style={{ width: `${progressPercent}%` }}
              />
            </div>

            <div className="flex items-center justify-between w-full text-xs text-[#8C8275] font-mono mt-1">
              <span>ControlNet Geometry: LOCKED</span>
              <span className="font-semibold text-[#4A3B32]">{progressPercent}%</span>
            </div>
          </div>
        )}

        {/* State B: Paused at 99% - Deferred Gratification Email Gate */}
        {isPausedAt99 && (
          <div>
            {/* Header badge */}
            <div className="flex items-center justify-between gap-2 mb-4">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold">
                <CheckCircle className="w-3.5 h-3.5" />
                <span>Makeover Ready (99% Synthesized)</span>
              </div>
              <div className="text-xs font-mono text-[#8C8275]">
                <span>100% Lease-Safe</span>
              </div>
            </div>

            <h3 className="font-serif text-2xl sm:text-3xl font-bold text-[#2C2724] leading-snug">
              Your Lease-Safe Makeover is Ready!
            </h3>
            
            <p className="text-sm text-[#655E56] mt-2 leading-relaxed">
              Enter your permanent email to instantly lift the preview blur and claim <strong className="text-[#4A3B32]">4 bonus free credits (5 total)</strong>.
            </p>

            {/* ZeroBounce Email Form */}
            <form onSubmit={handleSubmit} className="mt-6 flex flex-col gap-3">
              <div>
                <label className="block text-xs font-semibold text-[#4A3B32] uppercase tracking-wide mb-1.5">
                  Email Address for Spec Delivery
                </label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8C8275]" />
                  <input
                    type="email"
                    value={emailInput}
                    onChange={e => {
                      setEmailInput(e.target.value);
                      if (errorMessage) setErrorMessage('');
                    }}
                    placeholder="you@domain.com (No disposable emails)"
                    className="w-full pl-10 pr-4 py-3 rounded-xl border border-[#B8B2A6]/60 bg-white text-sm text-[#2C2724] focus:outline-none focus:ring-2 focus:ring-[#4A3B32] transition-all shadow-2xs"
                    disabled={isValidating || isSuccess}
                    autoFocus
                  />
                </div>
              </div>

              {/* Error message */}
              {errorMessage && (
                <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <p>{errorMessage}</p>
                </div>
              )}

              {/* Submit button */}
              <button
                type="submit"
                disabled={isValidating || isSuccess || !emailInput.trim()}
                className="w-full py-3.5 rounded-xl bg-[#4A3B32] hover:bg-[#382C25] active:scale-98 text-[#FAF8F5] font-semibold text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isValidating ? (
                  <>
                    <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Verifying with ZeroBounce...</span>
                  </>
                ) : isSuccess ? (
                  <>
                    <CheckCircle className="w-4 h-4 text-emerald-400" />
                    <span>Unblurring Design & Depositing 4 Credits...</span>
                  </>
                ) : (
                  <>
                    <span>Unblur Design & Claim 4 Free Credits</span>
                    <ArrowRight className="w-4 h-4 text-[#C69C6D]" />
                  </>
                )}
              </button>
            </form>

            {/* ZeroBounce verification note */}
            <div className="mt-4 pt-4 border-t border-[#B8B2A6]/30 flex items-center justify-between text-[11px] text-[#8C8275]">
              <span className="flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-[#6E7864]" /> Zero Spam · 100% Privacy
              </span>
              <span>ZeroBounce Active</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
